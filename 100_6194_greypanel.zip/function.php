<?php session_start();
	error_reporting( 0 );
	mb_internal_encoding("utf-8");
	require_once "conf/config.php";
	require_once "lib/manage_class.php";

	
	$manage = new Manage();
	if( isset( $_POST['refresh_server_vip'] ) ) {
		$r = $manage->addServerVip( 'update' );
	} 
	else if( isset( $_POST['read_user_admin'] ) ) {
		$r = $manage->readUserAdmin( );
	}  
	else if( isset( $_POST['update_forum_category'] ) ) {
		$r = $manage->updateForumCategory( );
	}  
	else if( isset( $_POST['update_forum_forum'] ) ) {
		$r = $manage->updateForumForum( );
	} 
	else if( isset( $_POST['add_forum_forum'] ) ) {
		$r = $manage->addForumForum( );
	}  
	else if( isset( $_POST['read_forum_list'] ) ) {
		$r = $manage->readForumList( );
	} 
	else if( isset( $_POST['read_category'] ) ) {
		$r = $manage->readCategory( );
	}  
	else if( isset( $_POST['add_forum_category'] ) ) {
		$r = $manage->addForumCategory( );
	}  
	else if( isset( $_POST['vip_server_privileg'] ) ) {
		$r = $manage->vipServerPrivileg( );
	} 
	else if( isset( $_POST['add_server_vip'] ) ) {
		$r = $manage->addServerVip( 'insert' );
	} 	
	else if( isset( $_POST['replie_like'] ) ) {
		$r = $manage->theardLike( $_POST['replie_like'], 'forum_replay' );
	} 
	else if( isset( $_GET['seend_delete_ban'] ) ) {
		$r = $manage->seendDeleteBan( $_GET['seend_delete_ban'] );
	}
	else if( isset( $_GET['seend_zayavka_bans'] ) ) {
		$r = $manage->seendZayavkaBans( $_GET['seend_zayavka_bans'] );
	}
	else if( isset( $_GET['search_bans'] ) ) {
		$r = $manage->searchBans( $_GET['search_bans'] );
	}  
	else if( isset( $_GET['delete_replie'] ) ) {
		$r = $manage->deleteReplie( $_GET['delete_replie'] );
	}  
	else if( isset( $_POST['theard_lite'] ) ) {
		$r = $manage->theardLike( $_POST['theard_lite'], 'forum_theards' );
	} 
	else if( isset( $_POST['register'] ) ) {
		$r = $manage->register();
	} 
	else if( isset( $_GET['theard'] ) && isset( $_GET['closed'] ) ) {
		$r = $manage->deleteTheard( $_GET['theard'], 'closed', $_GET['closed'] );
	}  
	else if( isset( $_GET['theard'] ) && isset( $_GET['status'] ) ) {
		$r = $manage->deleteTheard( $_GET['theard'], 'status', $_GET['status'] );
	}   
	else if( isset( $_GET['theard'] ) && isset( $_GET['delete'] ) ) {
		$r = $manage->deleteTheard( $_GET['theard'], 'delete', $_GET['delete'] );
	} 
	else if( isset( $_POST['read_theard'] ) ) {
		$r = $manage->readTheard( 'forum_theards' , $_POST['theard'], $_POST['read_theard']);
	}  
	else if( isset( $_POST['read_replie'] ) ) {
		$r = $manage->readTheard( 'forum_replay' , $_POST['replie'], $_POST['read_replie']);
	} 
	else if( isset( $_POST['postmessege_topic'] ) ) {
		$r = $manage->postmessegeTopic();
	}  else if( isset( $_POST['postchangeavatar'] ) ) {
		$r = $manage->changeavatar();
	} else if( isset( $_GET['log'] ) ) {
		$r = $manage->logOut();
	} else if( isset( $_POST['autch'] ) ) {
		$r = $manage->autch();
	} else if( isset( $_POST['setting'] ) ) {
		$r = $manage->setting();
	} else if( isset( $_GET['vk_autch'] ) ) {
		$r = $manage->vkAutch( $_GET['code'] );
	} else if( isset( $_POST['create_theard'] ) ) {
		$r = $manage->createTheard();
	}
	else $r = ADDRESS;
	$manage->redirect( $r );
?>