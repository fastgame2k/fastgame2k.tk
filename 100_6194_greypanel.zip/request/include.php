<?php session_start();
require_once "../../conf/config.php";
if( defined( 'INCLUDE_R' ) ) {
	$_SESSION['err_msg'] = 'Ошибка';
	head();
}


require '../../lib/SourceQuery/bootstrap.php';
require_once "../../conf/ittems.php";
set_include_path( get_include_path() . PATH_SEPARATOR . "../../lib/mysql" . PATH_SEPARATOR . "../../lib/tables" . PATH_SEPARATOR . "../../lib/function" );
spl_autoload_extensions("_class.php");
spl_autoload_register(); 


function getPrava( $id, $number ) {
	$sql = new DataBase();
	#получаем группу юзера
	$getUserGroup = $sql->select(
		'users',
		[ 'group' ],
		[ 'id' => $id ]
	);	
	#Проверяем права, если он не рот админ - посылаем в лес) 
	if( $getUserGroup[0]['group'] == $number ) {
		return true;
	}	

	return false;		
}

#Редирект
function head( $uri = '' ) {
	header( "Location: ".ADDRESS.$uri );
	exit;
}

function rJson( $data ) {
	header("Content-type: application/json; charset=utf-8");
	echo json_encode( $data );
	exit();		
}

#Я использую для дебага
function pre( $pre ){
	echo '<pre>';
	print_R( $pre );
	die();
}