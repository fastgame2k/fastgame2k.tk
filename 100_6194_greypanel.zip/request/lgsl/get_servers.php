<?php

	require_once ( '../include.php' );
	
	define( 'INCLUDE_R', true );
	
	use xPaw\SourceQuery\SourceQuery;
	
	
	$getServers = lgsl::select( '*', [ 'disabled' => '0' ]);
	if( is_array( $getServers ) ) {
		for( $i = 0; $i < count( $getServers ); $i++ ) { 
			if( $getServers[$i]['cache_time'] + 600 < time() ) {
				if( $getServers[$i]['type'] == "halflife" ){
					$types = SourceQuery::GOLDSOURCE;
				}
				if( $getServers[$i]['type'] == "source" ){
					$types = SourceQuery::SOURCE;
				}
				
				$Query = new SourceQuery( );
				try
				{
					$Query->Connect( $getServers[$i]['ip'], $getServers[$i]['c_port'], 1, $types );
					$server_info['info'] = $Query->GetInfo( );
					$server_info['players'] =$Query->GetPlayers( );
					$status = 0;
					$Query->Disconnect( );
				}
				catch( Exception $e )
				{
					$status = 1;
				}
				
				lgsl::update(
					[
						'cache' => serialize( $server_info ),
						'status' => $status,
						'cache_time' => time(),
					],
					[ 'id' => $getServers[$i]['id'] ]
				);
			}
			
			$server_name = $getServers[$i]['cache']['info']['HostName'];
			$players = $getServers[$i]['cache']['info']['Players'].'/'.$getServers[$i]['cache']['info']['MaxPlayers'];
			$address = $getServers[$i]['ip'].':'.$getServers[$i]['c_port'];
			$map = $getServers[$i]['cache']['info']['Map'];
			$type = $getServers[$i]['type'];
			$id = $getServers[$i]['id'];
			$status = $getServers[$i]['status'];

			if( $status == '1' ) {
				$status = '<span class="badge badge-danger badge-header">off</span>';
			} else {
				$status = '<span class="badge badge-success badge-header">on</span>';
			}
			$array[$i] = [ 
				'id' => $id, 
				'status' => $status,
				'type' => $type, 
				'server_name' => $server_name, 
				'map' => $map, 
				'players' => $players, 
				'address' => $address
			];
		}
	}
	
	rJson( $array );