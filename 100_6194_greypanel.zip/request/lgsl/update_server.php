<?php
	if( !isset( $_POST ) ) 
		die();
	require_once ( '../include.php' );
	define( 'INCLUDE_R', true );
	if( !getPrava( $_SESSION['id'], 4 ) ) {
		$_SESSION['err_msg'] = 'Нету прав для Обновления сервера';
		head();
	}
	
    $type = $_POST['type'];
    $ip = $_POST['ip'];
    $c_port = $_POST['c_port'];
    $q_port = $_POST['c_port'];
    $s_port = $_POST['c_port'];
    $server_id = ( int ) $_POST['server_id'];
    $disabled = ( int ) $_POST['disabled'];
	
	use xPaw\SourceQuery\SourceQuery;
	
    if( $type == "halflife" ){
        $types = SourceQuery::GOLDSOURCE;
    }
    if( $type == "source" ){
        $types = SourceQuery::SOURCE;
    }
	$Query = new SourceQuery( );
	
	try
	{
		$Query->Connect( $ip, $c_port, 1, $types );
		
		$server_info['info'] = $Query->GetInfo( );
		$server_info['players'] =$Query->GetPlayers( );
		$Query->Disconnect( );
	}
	catch( Exception $e )
	{
		$_SESSION['err_msg'] = $e->getMessage( );
		head( 'admin/monitor' );
	}
	
	lgsl::update(
		[
			'type' => $type,
			'ip' => $ip,
			'c_port' => $c_port,
			'q_port' => $q_port,
			's_port' => $s_port,
			'disabled' => $disabled,
			'cache' => serialize( $server_info ),
			'cache_time' => time(),
		],
		[ 'id' => $server_id ]
	);
	
	$_SESSION['msg'] = 'Сервер успешно обновлен';
	
	head( 'admin/monitor' );