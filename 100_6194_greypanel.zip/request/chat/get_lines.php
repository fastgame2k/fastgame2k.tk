<?php
	require_once ( '../include.php' );
	
	define( 'INCLUDE_R', true );
	
	$last = ( int ) $_GET['last'];
	
	if( $last == 0 ) {
		$chatLines = chat::select( '20' );
	} else if( is_numeric( $last ) ) {
		$chatLines = chat::select( '20', "`id` > '{$last}'", true );
	}
	if( !is_array( $chatLines ) ) 
		exit;
	
	$DataBase = new DataBase();
	sort( $chatLines );
	for( $i = 0; $i < count( $chatLines ); $i++ ) {
		
		$users = $DataBase->select( 'users', [ 'username', 'avatar' ], [ 'id' => $chatLines[$i]['autor_id'] ] );
		$users = $users[0];
		$data[] = [ 
			'status' => 200, 
			'msg' => $chatLines[$i]['msg'],
			'time' => $chatLines[$i]['time_add'],
			'id' => $chatLines[$i]['id'],
			'username' => $users['username'], 
			'avatar' => $users['avatar'], 
		];	
	}

	rJson($data);
	
	