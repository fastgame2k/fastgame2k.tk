<?php

	if( !isset( $_POST ) ) 
		die();
	require_once ( '../include.php' );
	
	define( 'INCLUDE_R', true );
	if( !isset( $_SESSION['id'] ) ) {
		$data = [ 'status' => 1, 'msg' => 'В чат могут отправлять только пользователи' ];
		rJson($data);
	}
	$msg = trim( $_POST['msg'] );
	
	if ( empty( $msg ) ) {
		$data = [ 'status' => 1, 'msg' => 'Заполните сообщение' ];
		rJson($data);
	}
	
	$getLine = chat::insert([
		'autor_id' => $_SESSION['id'],
		'msg' => $msg,
		'time_add' => time()
	]);
	$DataBase = new DataBase();
	$users = $DataBase->select( 'users', [ 'username', 'avatar' ], [ 'id' => $_SESSION['id'] ] );
	$users = $users[0];
	if( $getLine ) {
		
		$data = [ 
			'status' => 200, 
			'msg' => htmlspecialchars( $msg ),
			'username' => $users['username'], 
			'id' => $getLine, 
			'avatar' => $users['avatar'], 
			'time' => 'Только что'
		];
		rJson($data);
	}
	
	
	$data = [ 'status' => 1, 'msg' => 'Ошибка отправки сообщения' ];
	rJson($data);