<?php
	if( !isset( $_GET['privileg_id'] ) ) 
		die();
	
	require_once ( '../include.php' );
	
	define( 'INCLUDE_R', true );
	if( !getPrava( $_SESSION['id'], 4 ) ) {
		exit;
	}
	
	$privileg_id = ( int ) $_GET['privileg_id'];
	
	
	$vip_users = vip_users::select( [ 'id' => $privileg_id ] );
	
	if( !is_array( $vip_users ) )
		exit('1');
	$vip_users_server = vip_servers::getIdAdmin($vip_users[0]['server_data'][0]['id']);
	if( $vip_users_server['type'] == 0 ) {
		$host = $vip_users_server['host'];
		$user = $vip_users_server['user'];
		$password = $vip_users_server['password'];
		$bd = $vip_users_server['bd'];
		$type = $vip_users_server['type'];
		$prefix = $vip_users_server['prefix']; 
		$amx_id = $vip_users_server['amx_id']; 
		$getDelete = admins_servers::delete( 
			[ 'admin_id' => $vip_users[0]['amx_id'], 'server_id' => $amx_id ] ,
			$host, $user, $password, $bd, $prefix
		);
		
		if( !$getDelete )
			exit('1');
	}
	vip_users::delete( [ 'id' => $privileg_id ] );
	exit('200');
	
	
	
	
	