<?php
	if($_SERVER["REQUEST_METHOD"] != "POST")
		die('1');
	require_once ( '../include.php' );
	
	define( 'INCLUDE_R', true );
	if( !getPrava( $_SESSION['id'], 4 ) ) {
		$_SESSION['err_msg'] = 'Нету прав для Обновления сервера';
		head();
	}
	
	
    $SITENAME = $_POST['SITENAME'];
    $CRON_KEY = $_POST['CRON_KEY'];
    $DEFAULT_APP = $_POST['DEFAULT_APP'];
	
	if( empty( $SITENAME ) ) {
		$_SESSION['err_msg'] = 'Заполните название сайта';
		head('admin');
	}	
	if( empty( $CRON_KEY ) ) {
		$_SESSION['err_msg'] = 'Заполните секретный ключ для крона';
		head('admin');
	}	
	if( empty( $DEFAULT_APP ) ) {
		$_SESSION['err_msg'] = 'Заполните стандартное приложение';
		head('admin');
	}
    $THE_CHAT = ( $_POST['THE_CHAT'] == 'on' ) ? 'true' : 'false';
    $LGSL_ACTIVE = ( $_POST['LGSL_ACTIVE'] == 'on' ) ? 'true' : 'false';
    $WARCRAFT_BUE = ( $_POST['WARCRAFT_BUE'] == 'on' ) ? 'true' : 'false';
    $VK_AUTORIZE = ( $_POST['VK_AUTORIZE'] == 'on' ) ? 'true' : 'false';
    $VK_APP_ID = $_POST['VK_APP_ID'];
    $VK_APP_KEY = $_POST['VK_APP_KEY'];
    $ROBOCASSA = ( $_POST['ROBOCASSA'] == 'on' ) ? 'true' : 'false';
    $robocassa_id = $_POST['robocassa_id'];
    $robocassa_password = $_POST['robocassa_password'];
    $robocassa_password2 = $_POST['robocassa_password2'];
    $WEBMONEY = ( $_POST['WEBMONEY'] == 'on' ) ? 'true' : 'false';

    $AMXBANS_ACTIVE = ( $_POST['AMXBANS_ACTIVE'] == 'on' ) ? 'true' : 'false';
    $AMXBANS_IP_ADRES = $_POST['AMXBANS_IP_ADRES'];
    $AMXBANS_DB_USER = $_POST['AMXBANS_DB_USER'];
    $AMXBANS_DB_PASSWORD = $_POST['AMXBANS_DB_PASSWORD'];
    $AMXBANS_DB = $_POST['AMXBANS_DB'];
    $AMXBANS_PREFIX = $_POST['AMXBANS_PREFIX'];
    $AMXBANS_CODIROVKA = $_POST['AMXBANS_CODIROVKA'];
    $AMXBANS_FORUM = $_POST['AMXBANS_FORUM'];
    $CSSTATS_ACTIVE = ( $_POST['CSSTATS_ACTIVE'] == 'on' ) ? 'true' : 'false';
    $CSSTATS_IP_ADRES = $_POST['CSSTATS_IP_ADRES'];
    $CSSTATS_DB_USER = $_POST['CSSTATS_DB_USER'];
    $CSSTATS_DB_PASSWORD = $_POST['CSSTATS_DB_PASSWORD'];
    $CSSTATS_DB = $_POST['CSSTATS_DB'];
    $CSSTATS_PREFIX = $_POST['CSSTATS_PREFIX'];
    $CSSTATS_CODIROVKA = $_POST['CSSTATS_CODIROVKA'];
    $CSSTATS_TABLE = $_POST['CSSTATS_TABLE'];
	
    $webmoney_r = $_POST['webmoney_r'];
    $webmoney_u = $_POST['webmoney_u'];
    $webmoney_z = $_POST['webmoney_z'];
	
	$WMU_KURS = $_POST['WMU_KURS'];
	$WMZ_KURS = $_POST['WMZ_KURS'];
	$WEBMONEY_SECRET_KEY = $_POST['WEBMONEY_SECRET_KEY'];
	
	$of = fopen( '../../conf/config.php', "w+"); 
	fwrite( $of, '<?php
#Название сайта
define ( \'SITENAME\',\'greykoo\' ); 


#IP адрес MySQL
define ( \'IP_ADRES\', \''.IP_ADRES.'\' ); 
# пользователь MySQL
define ( \'DB_USER\', \''.DB_USER.'\' ); 
# пароль MySQL
define ( \'DB_PASSWORD\', \''.DB_PASSWORD.'\' );
# БД MySQL
define ( \'DB\', \''.DB.'\'); 
# Префикс MySQL
define ( \'PREFIX\', \''.PREFIX.'\'); 


define ( \'WARCRAFT_BUE\', '.$WARCRAFT_BUE.' ); #Включить покупку опыта варкрафт?
define ( \'LGSL_ACTIVE\', '.$LGSL_ACTIVE.' ); #Включить мониторинг?


define ( \'AMXBANS_ACTIVE\', '.$AMXBANS_ACTIVE.' ); 
#Настройка AmxBans
define ( \'AMXBANS_IP_ADRES\', \''.$AMXBANS_IP_ADRES.'\' ); 
define ( \'AMXBANS_DB_USER\', \''.$AMXBANS_DB_USER.'\' ); 
define ( \'AMXBANS_DB_PASSWORD\', \''.$AMXBANS_DB_PASSWORD.'\' );
define ( \'AMXBANS_DB\', \''.$AMXBANS_DB.'\' ); 
define ( \'AMXBANS_PREFIX\', \''.$AMXBANS_PREFIX.'\' ); 
define ( \'AMXBANS_FORUM\', \''.$AMXBANS_FORUM.'\' ); 
define ( \'AMXBANS_CODIROVKA\', \''.$AMXBANS_CODIROVKA.'\' ); 

#Включить статистику?
define ( \'CSSTATS_ACTIVE\', '.$CSSTATS_ACTIVE.' ); 
#Настройка Статистики MySQL
define ( \'CSSTATS_IP_ADRES\', \''.$CSSTATS_IP_ADRES.'\' ); 
define ( \'CSSTATS_DB_USER\', \''.$CSSTATS_DB_USER.'\' ); 
define ( \'CSSTATS_DB_PASSWORD\', \''.$CSSTATS_DB_PASSWORD.'\' );
define ( \'CSSTATS_DB\', \''.$CSSTATS_DB.'\' ); 
define ( \'CSSTATS_PREFIX\', \''.$CSSTATS_PREFIX.'\' ); 
define ( \'CSSTATS_CODIROVKA\', \''.$CSSTATS_CODIROVKA.'\' ); 
define ( \'CSSTATS_TABLE\', \''.$CSSTATS_TABLE.'\' ); 


#Настройка крона ссылка для запуста http://ваш.сайт/cron.php?cron=(ваш ключ)
define ( \'CRON_KEY\', \''.$CRON_KEY.'\' ); //ключ для ссылки

#Стандартный модуль сайта
define ( \'DEFAULT_APP\', \''.$DEFAULT_APP.'\' );  //стандартный модуль

#Настройки чата
define( \'THE_CHAT\', '.$THE_CHAT.' ); // true -- включить

#Настройка Авторизации ВК
define( \'VK_AUTORIZE\', '.$VK_AUTORIZE.' ); // true -- включить
define ( \'VK_APP_ID\', \''.$VK_APP_ID.'\' ); 
define ( \'VK_APP_KEY\', \''.$VK_APP_KEY.'\' ); 

#Настройка вебмани кошельков
define( \'WEBMONEY\', '.$WEBMONEY.' ); // true -- включить
$webMoney = [ 
	\'wmr\' => \''.$webmoney_r.'\', 
	\'wmz\' => \''.$webmoney_z.'\', 
	\'wmu\' => \''.$webmoney_u.'\',
];
#секретный ключ вебмани
define (\'WEBMONEY_SECRET_KEY\', \''.$WEBMONEY_SECRET_KEY.'\'); 

#курс гривен
define (\'WMU_KURS\', \''.$WMU_KURS.'\'); 
#курс рублей
define (\'WMZ_KURS\', \''.$WMZ_KURS.'\'); 

#Настройки робокассы
define( \'ROBOCASSA\', '.$ROBOCASSA.' ); //включить?
define( \'robocassa_id\', \''.$robocassa_id.'\' );
define( \'robocassa_password\', \''.$robocassa_password.'\' );
define( \'robocassa_password2\', \''.$robocassa_password2.'\' );


# отладчики 
define ( \'GET_DEV\', false );  //режим разработчика
define ( \'DIR_TPL\', \'theme/\' ); 

#Ссылка на сайт
define ( \'ADDRESS\',\'http://\'.$_SERVER[\'SERVER_NAME\'].\'/\' );' );
	fclose($of);
	
	$_SESSION['msg'] = 'Конфиг успешно обновлен';
	head('admin');