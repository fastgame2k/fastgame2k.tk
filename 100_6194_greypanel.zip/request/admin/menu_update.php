<?php
	if( !isset( $_POST ) ) 
		die();
	require_once ( '../include.php' );
	
	define( 'INCLUDE_R', true );
	if( !getPrava( $_SESSION['id'], 4 ) ) {
		$_SESSION['err_msg'] = 'Нету прав для Обновления сервера';
		head();
	}
	
    $text = trim( $_POST['text'] );
    $module = trim( $_POST['module'] );
    $desc = trim( $_POST['desc'] );
    $icon = trim( $_POST['icon'] );
    $ses = ( int ) $_POST['ses'];
    $active = ( int ) $_POST['active'];
    $menuid = ( int ) $_POST['menuid'];
	
	if( empty( $text ) ) {
		$_SESSION['msg'] = 'Заполните поле "Название меню"';
		head('admin/menu');		
	}	
	/*
	if( empty( $module ) ) {
		$_SESSION['msg'] = 'Заполните поле "Модуль"';
		head('admin/menu');		
	}
	*/
	menu::update(
		[
			'active' => $active,
			'text' => $text,
			'desc' => $desc,
			'module' => $module,
			'icon' => $icon,
			'ses' => $ses,
		],
		[ 'id' => $menuid ]
	);
	
	$_SESSION['msg'] = 'Меню успешно обновлено';
	head('admin/menu');