<?php
	error_reporting( 0 );
	require_once ( '../include.php' );
	if($_SERVER["REQUEST_METHOD"] != "POST")
		rJson( [ 'status' => 1, 'msg' => 'Ошибка 1 '] );
	
	
	define( 'INCLUDE_R', true );
	if( !getPrava( $_SESSION['id'], 4 ) ) {
		rJson( [ 'status' => 1, 'msg' => 'Ошибка, нету доступа '] );
	}
	
	$server_id = $_POST['server_id'];
	$flags = $_POST['flags'];
	$vipDays = $_POST['days'];
	$user_id = $_POST['user_id'];
	
	$sql = new DataBase();
	
	#Получаем юзера
	$getUserMoney = $sql->select(
		'users',
		[ 'username','password'  ],
		[ 'id' => $user_id ]
	);


	$vip_servers = vip_servers::getIdAdmin( $server_id );

	$host = $vip_servers['host'];
	$user = $vip_servers['user'];
	$password = $vip_servers['password'];
	$bd = $vip_servers['bd']; 
	$prefix = $vip_servers['prefix'];


	if( $vip_servers['type'] == '0' ) {
		
		$getUserAmxAdmin = amxadmins::getAmxAdmin( $getUserMoney[0]['username'], $host, $user, $password,  $bd, $prefix );
		
		if( !is_array( $getUserAmxAdmin ) ) {
			#Создаем юзера в amxADmin
			
			$insertAdmin = amxadmins::addAmxBans( 
			[ 
				'username' => 	$getUserMoney[0]['username'],
				'password' => 	md5( $getUserMoney[0]['password'] ),
				'steamid' =>	$getUserMoney[0]['username'],
				'nickname' => 	$getUserMoney[0]['username'],
				'created' => 	time(),
				'expired' => 	0,
				'flags' => 	'a',
				'days' => 		0,
			],
			$host, $user, $password,  $bd, $prefix );
		} else {
			$insertAdmin = $getUserAmxAdmin['id'];
			#Сверяем хеш паролей
			
			if( $getUserAmxAdmin['password'] != md5( $getUserMoney[0]['password'] ) ) {
				#Обновляем пароль если он не верный
				$update_password = amxadmins::updateAmxAdmin(
					[ 'password' => md5( $getUserMoney[0]['password'] ) ],
					[ 'id' => $insertAdmin ],
					$host, $user, $password,  $bd, $prefix
				);
				if( !$update_password ) {
					rJson( [ 'status' => 1, 'msg' => 'Ошибка обновления пароля'] );
				}
			}
		}
		
		if( !$insertAdmin ) {
			rJson( [ 'status' => 1, 'msg' => 'Ошибка отправки запроса на сервер, пожалуйста подождите немного и попробуйте еще раз. А так же сообщите администратору.'] );
		} 

		$getVipUsersSite = vip_users::select([
			'user_id' => $user_id,
			'amx_id' => $insertAdmin,
			'server_id' => $vip_servers['amx_id'],
		]);	

		if( !$getVipUsersSite ) {
			#добавляем пользователя
			$timeAdmin = time() + $vipDays * 97400;
			vip_users::insert([
				'user_id' => $_SESSION['id'],
				'amx_id' => $insertAdmin,
				'server_id' => $vip_servers['amx_id'],
				'custom_flags' => $flags,
				'created' => time(),
				'expired' => $timeAdmin,
			]); 
		} else {
			
			#Сверяем флаги, если он активирует ту же услугу - продливаем её, если нет - активируем новое время
			if( $getVipUsersSite[0]['custom_flags'] == $flags  ) {
				$timeAdmin = $getVipUsersSite[0]['expired'] + $vipDays * 97400;
			} else {
				$timeAdmin = time() + $vipDays * 97400;
			}
			
			vip_users::update(
				[
					'custom_flags' => $flags,
					'expired' => $timeAdmin,
				],
				[
					'user_id' => $_SESSION['id'],
					'amx_id' => $insertAdmin,
					'server_id' => $vip_servers['amx_id'],							
				]
			);	
		}
		$getAmmxPrava = admins_servers::getAmxAdmin( 
			[ 
				'admin_id' => $insertAdmin,
				'server_id' => $vip_servers['amx_id'],
			],
			$host,
			$user,
			$password,
			$bd,
			$prefix
		);
		#проверяем права 
		if( !$getAmmxPrava ) {
			#Создаем ему права на сервере
			$admins_servers = admins_servers::addAmxBans( 
				[ 
					'admin_id' => 				$insertAdmin,
					'server_id' => 				$vip_servers['amx_id'],
					'custom_flags' =>			$flags,
					'use_static_bantime' => 	'yes',
				],
				$host,
				$user,
				$password,
				$bd,
				$prefix
			);
		} else { 
			#Обновляем ему флаги
			admins_servers::updateAmxAdmin(
				[ 'custom_flags' => $flags ],
				[ 'admin_id' => $insertAdmin, 'server_id' => $vip_servers['amx_id'] ],
				$host,
				$user,
				$password,
				$bd,
				$prefix	
			);
		}	
	
		
	} else { 
		// устанавливает соединение или выходит
		$conn_id = ftp_connect( $host ); 
		if( !$conn_id ) 
			rJson( [ 'status' => 1, 'msg' => 'Ошибка в подключении к серверу'] );
		
		if ( !ftp_login( $conn_id, $user, $password ) ) 
			rJson( [ 'status' => 1, 'msg' => 'Ошибка в настройках сервера.. не верный логин и пароль'] );
		
		if(!ftp_get( $conn_id, '../../upload/users.ini', $bd, FTP_BINARY )){
			
			rJson( [ 'status' => 1, 'msg' => 'Не удалось поключиться к файлу настройки сервера'] );
		}
	
		$getVipUsersSite = vip_users::select([
			'user_id' => $user_id,
			'server_id' => $vip_servers['id'],
		]);

		if( !$getVipUsersSite ) {
			#добавляем пользователя
			$timeAdmin = time() + $vipDays * 97400;
			vip_users::insert([
				'user_id' => $user_id,
				'amx_id' => '0',
				'server_id' => $vip_servers['id'],
				'custom_flags' => $flags,
				'created' => time(),
				'expired' => $timeAdmin,
			]);
		} else {
			#Сверяем флаги, если он активирует ту же услугу - продливаем её, если нет - активируем новое время
			if( $getVipUsersSite[0]['custom_flags'] == $flags  ) {
				$timeAdmin = $getVipUsersSite[0]['expired'] + $vipDays * 97400;
			} else {
				$timeAdmin = time() + $vipDays * 97400;
			}
			
			//$timeAdmin = $getVipUsersSite[0]['expired'] + $vip_days[$vip_server_days] * 97400;
			vip_users::update(
				[
					'custom_flags' => $flags,
					'expired' => $timeAdmin,
				],
				[
					'user_id' => $user_id,
					'server_id' => $vip_servers['id'],							
				]
			);	
		}	 

		#Получаем всех юзеров с сервера
		$getAllUsersServer = vip_users::select([
			'server_id' => $vip_servers['id']
		]);
		

		
		$formateUsers = '';
		for( $i = 0; $i < count( $getAllUsersServer ); $i++ ) {
			
			#Получаем юзера
			$getUserName = $sql->select(
				'users',
				[ 'username','password'  ],
				[ 'id' => $getAllUsersServer[$i]['user_id'] ]
			);
			
			$formateUsers .= "\"".$getUserName[0]['username']."\" \"".$getUserName[0]['password']."\" \"".$getAllUsersServer[$i]['custom_flags']."\" \"a\" ;Автоматическое добавление, конец админки ".$getAllUsersServer[$i]['timeAgo']."\n";
		}
		
		$of = fopen( '../../upload/users.ini', "w+"); 
		$line=fgets( $of ); 
		rewind( $of ); 
		fwrite( $of, $formateUsers );
		fclose($of);


		
		$fp = fopen( '../../upload/users.ini', 'r' );
		#Загружаем новый файл на сервер
		if ( !ftp_fput( $conn_id, $bd, $fp, FTP_ASCII ) ) {
			ftp_close( $conn_id );
			fclose($fp);
			rJson( [ 'status' => 1, 'msg' => 'Ошибка сохраненнии прав'] );
		}
		ftp_close( $conn_id );
		fclose($fp);
		
	}
	
	$data = [ 'status' => 200, 'flags' => $flags, 'server_name' => $vip_servers['server_name'], 'vipDays' => $vipDays ];

	rJson( $data );