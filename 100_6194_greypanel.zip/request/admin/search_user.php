<?php
	if( !isset( $_GET['words'] ) ) 
		die();
	
	require_once ( '../include.php' );
	
	define( 'INCLUDE_R', true );
	if( !getPrava( $_SESSION['id'], 4 ) ) {
		exit;
	}
	GLOBAL $groups_Users;
	$words = $_GET['words'];
	
	$search = users::search( $words );
	
	if( is_array( $search ) ) {
		for( $i = 0; $i < count( $search ); $i++ ) {
			$data[$i] = [
				'id' => $search[$i]['id'],
				'username' => htmlspecialchars( $search[$i]['username'] ),
				'email' => htmlspecialchars( $search[$i]['email'] ),
				'money' => $search[$i]['money'],
				'group' => $groups_Users[ $search[$i]['group'] ],
				'reg_data' => times::timeAgo( $search[$i]['reg_data'] ),
			];		
		}
	} else {
		
		$data = null;
	}

	
	rJson( $data );