<?php
	if( !isset( $_POST ) ) 
		exit;
	require_once ( '../include.php' );
	
	define( 'INCLUDE_R', true );
	if( !getPrava( $_SESSION['id'], 4 ) ) {
		exit;
	}
	
	
	$new_pos = 1; 
	foreach ( $_POST['read_category'] as $item )
	{
		menu::update(
			[ 'num' => $new_pos ],
			[ 'id' =>  $item ]
		);
		$new_pos++;
	}
	return true;
	