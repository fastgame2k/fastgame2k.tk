<?php
	/*
	Автор панели grey
	Демо сайт greyko.ru , а так же тех поддержка и стол запросов
	Скрипт бесплатный
	*/
	mb_internal_encoding("utf-8");
	require_once "conf/config.php";
	require_once "conf/ittems.php";
	if( GET_DEV ) {
		error_reporting( E_ALL );
	} else {
		error_reporting( 0 );
	}
	
	mb_internal_encoding("utf-8");
	set_include_path( get_include_path() . PATH_SEPARATOR . "lib/mysql" . PATH_SEPARATOR . "lib/tables" . PATH_SEPARATOR . "lib/function" );
	spl_autoload_extensions("_class.php");
	spl_autoload_register();
	
	require_once "lib/modules_class.php"; 
	$content = new grey();

	echo $content->getContent();
?>


