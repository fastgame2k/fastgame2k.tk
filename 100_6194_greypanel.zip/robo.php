<?php
	require_once "conf/config.php";
	
	$mrh_pass2 = robocassa_password2;


	$out_summ = $_REQUEST["OutSum"];
	$inv_id = $_REQUEST["InvId"];
	$shp_item = $_REQUEST["Shp_item"];
	$crc = $_REQUEST["SignatureValue"];
	$session_id = $_REQUEST["session_id"];

	$crc = strtoupper($crc);

	$my_crc = strtoupper(md5("$out_summ:$inv_id:$mrh_pass2:Shp_item=$shp_item"));

	if ($my_crc !=$crc)
	{
	  echo "bad sign\n";
	  exit();
	}
		set_include_path( get_include_path() . PATH_SEPARATOR . "lib/mysql" . PATH_SEPARATOR . "lib/tables" . PATH_SEPARATOR . "lib/function" );
		spl_autoload_extensions("_class.php");
		spl_autoload_register();

		//$getUserId = users::getId( $userId );
		$sql = new DataBase();

	
		$userId = ( int )$_POST['id'];
		
		$getUserId = $sql->select( 
			'users',
			'*',
			[ 'id' => $userId ]
		);
		
		$money = $out_summ;
		#Добавляем деньги
		$getAdd = users::update(
			[ 'money' => $getUserId[0]['money'] + $money ],
			[ 'id' => $userId ]
		);
		
		money_logs::insert([
			'user_id' => $userId,
			'tupe' => '1',
			'money' => $money,
			'title' => 'Пополнение счета через вебмани'
		]);
		
		echo "OK$inv_id\n";

?>