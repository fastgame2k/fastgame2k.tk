<?php


		if (isset($_POST['LMI_PREREQUEST']) == 1) {
			echo 'YES';
			exit();
		} 
		require_once "conf/config.php";
		// Склеиваем строку параметров
		$common_string = $_POST['LMI_PAYEE_PURSE'].$_POST['LMI_PAYMENT_AMOUNT'].$_POST['LMI_PAYMENT_NO'].
		 $_POST['LMI_MODE'].$_POST['LMI_SYS_INVS_NO'].$_POST['LMI_SYS_TRANS_NO'].
		 $_POST['LMI_SYS_TRANS_DATE'].WEBMONEY_SECRET_KEY.$_POST['LMI_PAYER_PURSE'].$_POST['LMI_PAYER_WM'];
		// Шифруем полученную строку в SHA256 и переводим ее в верхний регистр
		$hash = strtoupper(hash("sha256",$common_string));
		if($hash!=$_POST['LMI_HASH']) 
			exit;
	  
		
		set_include_path( get_include_path() . PATH_SEPARATOR . "lib/mysql" . PATH_SEPARATOR . "lib/tables" . PATH_SEPARATOR . "lib/function" );
		spl_autoload_extensions("_class.php");
		spl_autoload_register();

		//$getUserId = users::getId( $userId );
		$sql = new DataBase();

	
		$userId = ( int )$_POST['id'];
		
		$getUserId = $sql->select( 
			'users',
			'*',
			[ 'id' => $userId ]
		);
		$getKowelek = $_POST['LMI_PAYEE_PURSE'];
		
		if( $getKowelek{0} == 'R' ) {
			$money = $_POST['LMI_PAYMENT_AMOUNT'];
		} else if( $getKowelek{0} == 'U' ) {
			$money = $_POST['LMI_PAYMENT_AMOUNT'] * WMU_KURS;
		} else if( $getKowelek{0} == 'Z' ) {
			$money = $_POST['LMI_PAYMENT_AMOUNT'] * WMZ_KURS;
		}
		
	
	
		#Добавляем деньги
		$getAdd = users::update(
			[ 'money' => $getUserId[0]['money'] + $money ],
			[ 'id' => $userId ]
		);

		money_logs::insert([
			'user_id' => $userId,
			'tupe' => '1',
			'money' => $money,
			'title' => 'Пополнение счета через вебмани'
		]);
		exit( 'OK' ); 