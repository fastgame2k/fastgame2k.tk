<?php
#Название сайта
define ( 'SITENAME','greykoo' ); 


#IP адрес MySQL
define ( 'IP_ADRES', '127.0.0.1' ); 
# пользователь MySQL
define ( 'DB_USER', 'root' ); 
# пароль MySQL
define ( 'DB_PASSWORD', '' );
# БД MySQL
define ( 'DB', 'greypanel'); 
# Префикс MySQL
define ( 'PREFIX', 'grey_'); 


define ( 'WARCRAFT_BUE', false ); #Включить покупку опыта варкрафт?
define ( 'LGSL_ACTIVE', false ); #Включить мониторинг?


define ( 'AMXBANS_ACTIVE', false ); 
#Настройка AmxBans
define ( 'AMXBANS_IP_ADRES', '127.0.0.1' ); 
define ( 'AMXBANS_DB_USER', 'БД юзер' ); 
define ( 'AMXBANS_DB_PASSWORD', 'пароль' );
define ( 'AMXBANS_DB', 'База данных' ); 
define ( 'AMXBANS_PREFIX', 'amx_' ); 
define ( 'AMXBANS_FORUM', '2' ); 
define ( 'AMXBANS_CODIROVKA', 'ANCI' ); 

#Включить статистику?
define ( 'CSSTATS_ACTIVE', false ); 
#Настройка Статистики MySQL
define ( 'CSSTATS_IP_ADRES', '127.0.0.1' ); 
define ( 'CSSTATS_DB_USER', 'root' ); 
define ( 'CSSTATS_DB_PASSWORD', '' );
define ( 'CSSTATS_DB', 'stats_sql' ); 
define ( 'CSSTATS_PREFIX', '' ); 
define ( 'CSSTATS_CODIROVKA', 'UTF8' ); 
define ( 'CSSTATS_TABLE', 'csstats' ); 


#Настройка крона ссылка для запуста http://ваш.сайт/cron.php?cron=(ваш ключ)
define ( 'CRON_KEY', 'sdfsdfsdfsdf' ); //ключ для ссылки

#Стандартный модуль сайта
define ( 'DEFAULT_APP', 'forum' );  //стандартный модуль

#Настройки чата
define( 'THE_CHAT', false ); // true -- включить

#Настройка Авторизации ВК
define( 'VK_AUTORIZE', false ); // true -- включить
define ( 'VK_APP_ID', '' ); 
define ( 'VK_APP_KEY', '' ); 

#Настройка вебмани кошельков
define( 'WEBMONEY', false ); // true -- включить
$webMoney = [ 
	'wmr' => '', 
	'wmz' => '', 
	'wmu' => '',
];
#секретный ключ вебмани
define ('WEBMONEY_SECRET_KEY', ''); 

#курс гривен
define ('WMU_KURS', '4'); 
#курс рублей
define ('WMZ_KURS', '60'); 

#Настройки робокассы
define( 'ROBOCASSA', false ); //включить?
define( 'robocassa_id', '' );
define( 'robocassa_password', '' );
define( 'robocassa_password2', '' );


# отладчики 
define ( 'GET_DEV', false );  //режим разработчика
define ( 'DIR_TPL', 'theme/' ); 

#Ссылка на сайт
define ( 'ADDRESS','http://'.$_SERVER['SERVER_NAME'].'/' );