-- phpMyAdmin SQL Dump
-- version 4.2.12deb2+deb8u1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Янв 18 2016 г., 19:30
-- Версия сервера: 5.5.46-0+deb8u1
-- Версия PHP: 5.6.14-0+deb8u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `hots_social`
--

-- --------------------------------------------------------

--
-- Структура таблицы `grey_atach`
--

CREATE TABLE IF NOT EXISTS `grey_atach` (
  `id` int(11) NOT NULL,
  `autor_id` int(11) NOT NULL,
  `atach_url` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `grey_forum_category`
--

CREATE TABLE IF NOT EXISTS `grey_chat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `autor_id` int(11) NOT NULL,
  `msg` varchar(150) NOT NULL,
  `time_add` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `grey_forum_category` (
`id` int(11) NOT NULL,
  `title` varchar(250) NOT NULL,
  `desc` varchar(250) NOT NULL,
  `num` int(11) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `grey_forum_category`
--

INSERT INTO `grey_forum_category` (`id`, `title`, `desc`, `num`) VALUES
(1, 'Моя категория', 'Мой первый раздел', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `grey_forum_forums`
--

CREATE TABLE IF NOT EXISTS `grey_forum_forums` (
`id` int(11) NOT NULL,
  `category` int(11) NOT NULL,
  `title` varchar(250) NOT NULL,
  `desc` varchar(250) NOT NULL,
  `icon` varchar(150) NOT NULL DEFAULT 'fa fa-home',
  `num` int(11) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `grey_forum_forums`
--

-- --------------------------------------------------------
INSERT INTO `grey_forum_forums` (`id`, `category`, `title`, `desc`, `icon`, `num`) VALUES
(1, 1, 'Мой форум', 'Мой первый форум', 'fa fa-bullhorn', 1);
--
-- Структура таблицы `grey_forum_replay`
--

CREATE TABLE IF NOT EXISTS `grey_forum_replay` (
`id` int(11) NOT NULL,
  `theard_id` int(11) NOT NULL,
  `autor_id` int(11) NOT NULL,
  `content` text NOT NULL,
  `created` int(11) NOT NULL DEFAULT '0',
  `this_liked` text NOT NULL,
  `atach` text NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `grey_forum_theards`
--

CREATE TABLE IF NOT EXISTS `grey_forum_theards` (
`id` int(11) NOT NULL,
  `title` varchar(250) NOT NULL,
  `content` text NOT NULL,
  `created` int(11) NOT NULL DEFAULT '0',
  `autor_id` int(11) NOT NULL DEFAULT '0',
  `this_liked` text NOT NULL,
  `status` mediumint(1) NOT NULL DEFAULT '0',
  `deleted` mediumint(1) NOT NULL DEFAULT '0',
  `forum_id` mediumint(8) NOT NULL DEFAULT '1',
  `count_replay` int(11) NOT NULL DEFAULT '0',
  `last_post` int(11) NOT NULL DEFAULT '0',
  `closed` mediumint(1) NOT NULL DEFAULT '0',
  `atach` text NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

INSERT INTO `grey_forum_theards` (`id`, `title`, `content`, `created`, `autor_id`, `this_liked`, `status`, `deleted`, `forum_id`, `count_replay`, `last_post`, `closed`, `atach`) VALUES
(1, 'Спасибо за установку GreyPanel', 'Ура!!! Получилось! Заработало!\n\nСайт тех поддержки панели greyko.ru\nТам будут храниться все мануалы по настройки панели\n\nСказать спасибо разработчику \nR107969934836\nU179099912424', 1453039384, 1, 'a:1:{i:0;i:1;}', 1, 0, 1, 0, 1453039384, 0, '');

CREATE TABLE IF NOT EXISTS `grey_money_logs` (
`id` int(11) NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `tupe` tinyint(1) DEFAULT '0' COMMENT '0 - трата, 1 - приход денег',
  `money` int(11) NOT NULL,
  `title` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `grey_users`
--

CREATE TABLE IF NOT EXISTS `grey_users` (
`id` int(11) NOT NULL,
  `amx_id` int(11) NOT NULL DEFAULT '0',
  `username` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `group` tinyint(1) NOT NULL DEFAULT '0',
  `money` int(11) NOT NULL DEFAULT '0',
  `email` varchar(250) NOT NULL,
  `vk_id` int(11) NOT NULL DEFAULT '0',
  `userid` varchar(32) NOT NULL,
  `reg_data` int(11) NOT NULL DEFAULT '0',
  `avatar` varchar(500) NOT NULL DEFAULT 'public/img/avatars/avatar11_big.png',
  `access_token` text NOT NULL,
  `count_like` int(11) NOT NULL DEFAULT '0',
  `count_theard` int(11) NOT NULL DEFAULT '0',
  `count_post` int(11) NOT NULL DEFAULT '0',
  `forum_data` text NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

INSERT INTO `grey_users` (`id`, `amx_id`, `username`, `password`, `group`, `money`, `email`, `vk_id`, `userid`, `reg_data`, `avatar`, `access_token`, `count_like`, `count_theard`, `count_post`, `forum_data`) VALUES
(1, 0, 'admin', 'admin', 4, 0, 'admin@admin.ru', 0, '', 1453039149, 'public/img/avatars/avatar11_big.png', '', 1, 1, 0, '');

CREATE TABLE IF NOT EXISTS `grey_vip_servers` (
`id` int(11) NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 - amx_admin, 1 - FTP.',
  `host` varchar(250) NOT NULL,
  `amx_id` int(11) NOT NULL DEFAULT '0',
  `user` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `bd` varchar(250) NOT NULL,
  `prefix` varchar(250) NOT NULL,
  `server_name` varchar(250) NOT NULL,
  `server_ip` varchar(255) NOT NULL,
  `server_port` mediumint(5) NOT NULL,
  `privileg_data` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `grey_lgsl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ip` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `c_port` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `q_port` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `s_port` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `zone` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `disabled` tinyint(1) NOT NULL DEFAULT '0',
  `comment` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `cache` text COLLATE utf8_unicode_ci NOT NULL,
  `cache_time` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `grey_vip_users`
--

CREATE TABLE IF NOT EXISTS `grey_vip_users` (
`id` int(11) NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `amx_id` int(11) NOT NULL,
  `server_id` int(11) NOT NULL,
  `custom_flags` varchar(32) NOT NULL,
  `created` int(11) NOT NULL,
  `expired` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `grey_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `num` mediumint(5) NOT NULL,
  `text` varchar(50) NOT NULL,
  `desc` varchar(150) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `module` varchar(150) NOT NULL,
  `ses` mediumint(1) NOT NULL DEFAULT '0',
  `icon` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Дамп данных таблицы `grey_menu`
--

INSERT INTO `grey_menu` (`id`, `num`, `text`, `desc`, `active`, `module`, `ses`, `icon`) VALUES
(1, 3, 'Бан лист', 'Бан лист сервера', 1, 'bans', 0, 'fa fa-bug'),
(2, 4, 'Опыт Варкрафт', 'Покупка опыта Варкрафт', 1, 'warcraft', 1, 'fa fa-gavel'),
(3, 5, 'Статистика csstats', 'Статистика csstats', 1, 'csstats', 0, 'fa fa-bar-chart-o'),
(4, 6, 'Наша стена', 'Наша стена вконтакте', 1, 'feed', 0, 'fa fa-vk'),
(5, 1, 'Форум', 'Форум', 0, 'forum', 0, 'fa fa-bullhorn'),
(6, 2, 'Активация привилегий', 'Активация привилегий', 0, 'vip', 1, 'fa fa-bolt'),
(7, 7, 'Войти/Регистрация', 'Войти/Регистрация', 0, 'register', 2, 'fa fa-key');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `grey_forum_category`
--
ALTER TABLE `grey_forum_category`
 ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `grey_forum_forums`
--
ALTER TABLE `grey_forum_forums`
 ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `grey_forum_replay`
--
ALTER TABLE `grey_forum_replay`
 ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `grey_forum_theards`
--
ALTER TABLE `grey_forum_theards`
 ADD UNIQUE KEY `id_2` (`id`), ADD UNIQUE KEY `id_3` (`id`), ADD KEY `id` (`id`);

--
-- Индексы таблицы `grey_money_logs`
--
ALTER TABLE `grey_money_logs`
 ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `grey_users`
--
ALTER TABLE `grey_users`
 ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `grey_vip_servers`
--
ALTER TABLE `grey_vip_servers`
 ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `grey_vip_users`
--
ALTER TABLE `grey_vip_users`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `grey_forum_category`
--
ALTER TABLE `grey_forum_category`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1;
--
-- AUTO_INCREMENT для таблицы `grey_forum_forums`
--
ALTER TABLE `grey_forum_forums`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1;
--
-- AUTO_INCREMENT для таблицы `grey_forum_replay`
--
ALTER TABLE `grey_forum_replay`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1;
--
-- AUTO_INCREMENT для таблицы `grey_forum_theards`
--
ALTER TABLE `grey_forum_theards`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1;
--
-- AUTO_INCREMENT для таблицы `grey_money_logs`
--
ALTER TABLE `grey_money_logs`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `grey_users`
--
ALTER TABLE `grey_users`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1;
--
-- AUTO_INCREMENT для таблицы `grey_vip_servers`
--
ALTER TABLE `grey_vip_servers`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `grey_vip_users`
--
ALTER TABLE `grey_vip_users`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
