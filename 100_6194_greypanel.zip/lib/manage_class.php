<?php
/*
	Памятка функций 
	//проверка прав
	$this->getPrava( $_SESSION['id'], 3 ) //Ид юзера и его группа
*/
require_once "conf/ittems.php";
set_include_path( get_include_path() . PATH_SEPARATOR . "lib/mysql" . PATH_SEPARATOR . "lib/tables" . PATH_SEPARATOR . "lib/function" );
spl_autoload_extensions("_class.php");
spl_autoload_register(); 	


class Manage {
	protected $sql;
	
	public function __construct() {
		//session_start();
		$this->sql = new DataBase();
	}
	
	public function readUserAdmin() {
		if( !$this->getPrava( $_SESSION['id'], 4 ) ) {
			$_SESSION['err_msg'] = 'нету прав для редактирования';
			return ADDRESS;
		}	 
		$username  = $_POST['username'];
		$password  = $_POST['password'];
		$group  = ( int ) $_POST['group'];
		$money  = ( int ) $_POST['money'];
		$email  = $_POST['email'];
		$vk_id  = ( int ) $_POST['vk_id'];
		$avatar  = $_POST['avatar'];
		$count_like  = ( int ) $_POST['count_like'];
		$count_theard  = ( int ) $_POST['count_theard'];
		$count_post  = ( int ) $_POST['count_post'];
		$id  = ( int ) $_POST['read_user_admin'];
		$r = ADDRESS.'user?id='.$id;

		
		if( empty( $username ) ) {
			$_SESSION['err_msg'] = 'Напишите ник';
			return $r;
		}
		if( empty( $email ) ) {
			$_SESSION['err_msg'] = 'Напишите почту';
			return $r;
		}
		if( empty( $password )  ) {
			$_SESSION['err_msg'] = 'Напишите пароль';
			return $r;
		}
		
		if( is_array( $username ) ||  is_array( $email )  ||  is_array( $password ) ) {
			$_SESSION['err_msg'] = 'Массив запрещен';
			return $r;			
		}
		if( mb_strlen( $username ) > 32 || mb_strlen( $username ) < 1 ) {
			$_SESSION['err_msg'] = 'Логин должен содержать больше 1 символа и максимум 32';
			return $r;
		}
		
		if( !filter_var( $email, FILTER_VALIDATE_EMAIL ) ){ 
			$_SESSION['err_msg'] = 'Почта заполнена не верно';
			return $r;
		}
		
		users::update(
			[
				'username' => $username,
				'password' => $password,
				'group' => $group,
				'money' => $money,
				'email' => $email,
				'vk_id' => $vk_id,
				'avatar' => $avatar,
				'count_like' => $count_like,
				'count_theard' => $count_theard,
				'count_post' => $count_post,
			],
			[ 'id' => $id ]
		);
		
		$_SESSION['msg'] = 'Профиль обновлен';
		return $r;
	}
	
	public function updateForumCategory() {
		if( !$this->getPrava( $_SESSION['id'], 4 ) ) {
			$_SESSION['err_msg'] = 'нету прав для редактирования';
			return ADDRESS;
		}	

		$title = trim( $_POST['title']);
		$desc =  trim( $_POST['desc'] );
		$id = ( int ) $_POST['update_forum_category'];	

		if( $id == 0 ){
			$_SESSION['err_msg'] = 'Не выбран раздел';
			return ADDRESS.'forum/admin/';
		}
		
		if( empty( $title ) ) {
			$_SESSION['err_msg'] = 'Заполните название раздела';
			return ADDRESS.'forum/admin/';
		}	

		#Обновляем категорию форум
		
		$sql = forum_category::update(
			[
				'title' => $title,
				'desc' => $desc,
			],
			[ 'id' => $id ]
		);
		
		if( !$sql ) {
			$_SESSION['err_msg'] = 'Ошибка Обновления категории';
			return ADDRESS.'forum/admin/';
		}

		$_SESSION['msg'] = 'Категория обновлена';
		return ADDRESS.'forum/admin/';		
	}
	
	public function updateForumForum() {
		if( !$this->getPrava( $_SESSION['id'], 4 ) ) {
			$_SESSION['err_msg'] = 'нету прав для редактирования';
			return ADDRESS;
		}	
		$title = trim( $_POST['title']);
		$desc =  trim( $_POST['desc'] );
		$category = ( int ) $_POST['category'];
		$id = ( int ) $_POST['update_forum_forum'];
		$icon = trim( $_POST['icon']);
		
		if( $id == 0 ){
			$_SESSION['err_msg'] = 'Ошибка ID форума';
			return ADDRESS.'forum/admin/';
		}		
		if( $category == 0 ){
			$_SESSION['err_msg'] = 'Не выбрана категория форума';
			return ADDRESS.'forum/admin/';
		}
		
		if( empty( $title ) ) {
			$_SESSION['err_msg'] = 'Заполните название форума';
			return ADDRESS.'forum/admin/?cate='.$category;
		}	
/*		
		if( empty( $desc ) ) {
			$_SESSION['err_msg'] = 'Заполните описание форума';
			return ADDRESS.'forum/admin/?cate='.$category;
		}	
*/		
		if( empty( $icon ) ) {
			$_SESSION['err_msg'] = 'Выберите иконку форума';
			return ADDRESS.'forum/admin/?cate='.$category;
		}
		
		#Добавляем форум
		
		$sql = forum_forums::update(
			[
				'title' => $title,
				'desc' => $desc,
				'category' => $category,
				'icon' => $icon,
			],
			[ 'id' => $id ]
		);
		
		if( !$sql ) {
			$_SESSION['err_msg'] = 'Ошибка Обновления форума';
			return ADDRESS.'forum/admin/?cate='.$category;
		}

		$_SESSION['msg'] = 'Форум успешно обновлен';
		return ADDRESS.'forum/admin/?cate='.$category;
	}
	
	public function addForumForum() {
		if( !$this->getPrava( $_SESSION['id'], 4 ) ) {
			$_SESSION['err_msg'] = 'нету прав для редактирования';
			return ADDRESS;
		}	
		$title = trim( $_POST['title']);
		$desc =  trim( $_POST['desc'] );
		$category = ( int ) $_POST['category'];
		$icon = trim( $_POST['icon']);
		
		if( $category == 0 ){
			$_SESSION['err_msg'] = 'Не выбрана категория форума';
			return ADDRESS.'forum/admin/';
		}
		
		if( empty( $title ) ) {
			$_SESSION['err_msg'] = 'Заполните название форума';
			return ADDRESS.'forum/admin/?cate='.$category;
		}	
/*		
		if( empty( $desc ) ) {
			$_SESSION['err_msg'] = 'Заполните описание форума';
			return ADDRESS.'forum/admin/?cate='.$category;
		}
*/		
		if( empty( $icon ) ) {
			$_SESSION['err_msg'] = 'Выберите иконку форума';
			return ADDRESS.'forum/admin/?cate='.$category;
		}
		
		#Добавляем форум
		
		$sql = forum_forums::insert([
			'title' => $title,
			'desc' => $desc,
			'category' => $category,
			'icon' => $icon,
		]);
		
		if( !$sql ) {
			$_SESSION['err_msg'] = 'Ошибка добавления форума';
			return ADDRESS.'forum/admin/?cate='.$category;
		}

		$_SESSION['msg'] = 'Форум успешно добавлен';
		return ADDRESS.'forum/admin/?cate='.$category;
	}
	
	public function readForumList () {
		if( !$this->getPrava( $_SESSION['id'], 4 ) ) {
			$_SESSION['err_msg'] = 'нету прав для редактирования';
			return ADDRESS;
		}
	
		$new_pos = 1;
		$forum_id = ( int ) $_POST['category_forum_change'];
		foreach ( $_POST['read_forum_list'] as $item )
		{
			forum_forums::update(
				[ 'num' => $new_pos ],
				[ 'category' => $forum_id, 'id' =>  $item ]
			);
			$new_pos++;
		}
		return true;
	}
	
	public function readCategory () {
		if( !$this->getPrava( $_SESSION['id'], 4 ) ) {
			$_SESSION['err_msg'] = 'нету прав для редактирования';
			return ADDRESS;
		}
	
		$new_pos = 1;
		foreach ( $_POST['read_category'] as $item )
		{
			forum_category::update(
				[ 'num' => $new_pos ],
				[ 'id' =>  $item ]
			);
			$new_pos++;
		}
		return true;
	}
	
	public function addForumCategory() {
		if( !$this->getPrava( $_SESSION['id'], 4 ) ) {
			$_SESSION['err_msg'] = 'нету прав для редактирования';
			return ADDRESS;
		}
		
		
		$title = trim( $_POST['title'] );
		$desc =trim( $_POST['desc'] );
		if( empty( $title ) ) {
			$_SESSION['err_msg'] = 'Заполните название категории';
			return ADDRESS.'forum/admin/';
		}
		if( empty( $title ) ) {
			$_SESSION['err_msg'] = 'Заполните описание категории';
			return ADDRESS.'forum/admin/';
		}
		
		$cate = forum_category::insert([
			'title' => $title,
			'desc' => $title,
			'num' => time(),
		]);
		if( $cate ) {
			$_SESSION['msg'] = 'Категория успешно создана';
			return ADDRESS.'forum/admin/?cate='.$cate;
		}
		
		$_SESSION['err_msg'] = 'Ошибка добавления категории';
		return ADDRESS.'forum/admin/';
	}
	
	public function vipServerPrivileg() {
		if( !isset( $_SESSION['id'] ) ) {
			$_SESSION['err_msg'] = 'Активировать вип можно только пользователям';
			return ADDRESS;
		}
		$vip_server_id = ( int ) $_POST['vip_server_id'];
		$vip_server_days = ( int ) $_POST['vip_server_days'];
		$vip_server_privileg = ( int ) $_POST['vip_server_privileg'];
		
		
		$vip_servers = vip_servers::getIdAdmin( $vip_server_id );
		
		if( !is_array( $vip_servers['privileg_data'][$vip_server_privileg] ) )  {
			$_SESSION['err_msg'] = 'Ошибка! Попробуйте еще раз, нету такой привилегии';
			return ADDRESS;
		}
		GLOBAL $vip_days;
		#Цена за день
		$const = $vip_servers['privileg_data'][$vip_server_privileg]['const'];
		#Флаги
		$flags = $vip_servers['privileg_data'][$vip_server_privileg]['flags'];
		#Общая цена
		$allConst = $vip_days[$vip_server_days] * $const;	

		#Получаем деньги юзера
		$getUserMoney = $this->sql->select(
			'users',
			[ 'username','password', 'money'  ],
			[ 'id' => $_SESSION['id'] ]
		);

		
		if( $vip_servers['type'] == '0' ) {
			if( $getUserMoney[0]['money'] >= $allConst ) {
				#Получаем данные подключения
				$host = $vip_servers['host'];
				$user = $vip_servers['user'];
				$password = $vip_servers['password'];
				$bd = $vip_servers['bd']; 
				$prefix = $vip_servers['prefix'];
				
				#проверяем юзера в amxADmin
				
				$getUserAmxAdmin = amxadmins::getAmxAdmin( $getUserMoney[0]['username'], $host, $user, $password,  $bd, $prefix );
				
				if( !is_array( $getUserAmxAdmin ) ) {
					#Создаем юзера в amxADmin
					
					$insertAdmin = amxadmins::addAmxBans( 
					[ 
						'username' => 	$getUserMoney[0]['username'],
						'password' => 	md5( $getUserMoney[0]['password'] ),
						'steamid' =>	$getUserMoney[0]['username'],
						'nickname' => 	$getUserMoney[0]['username'],
						'created' => 	time(),
						'expired' => 	0,
						'flags' => 	'a',
						'days' => 		0,
					],
					$host, $user, $password,  $bd, $prefix );
				} else {
					$insertAdmin = $getUserAmxAdmin['id'];
					#Сверяем хеш паролей
					
					if( $getUserAmxAdmin['password'] != md5( $getUserMoney[0]['password'] ) ) {
						#Обновляем пароль если он не верный
						$update_password = amxadmins::updateAmxAdmin(
							[ 'password' => md5( $getUserMoney[0]['password'] ) ],
							[ 'id' => $insertAdmin ],
							$host, $user, $password,  $bd, $prefix
						);
						if( !$update_password ) {
							$_SESSION['err_msg'] = 'Ошибка обновления пароля';
							return ADDRESS.'vip/';
						}
					}
				}
				
				if( !$insertAdmin ) {

					$_SESSION['err_msg'] = 'Ошибка отправки запроса на сервер, пожалуйста подождите немного и попробуйте еще раз. А так же сообщите администратору.';
					return ADDRESS.'vip/';
				}  
				
				$getVipUsersSite = vip_users::select([
					'user_id' => $_SESSION['id'],
					'amx_id' => $insertAdmin,
					'server_id' => $vip_servers['amx_id'],
				]);
				
				if( !$getVipUsersSite ) {
					#добавляем пользователя
					$timeAdmin = time() + $vip_days[$vip_server_days] * 97400;
					vip_users::insert([
						'user_id' => $_SESSION['id'],
						'amx_id' => $insertAdmin,
						'server_id' => $vip_servers['amx_id'],
						'custom_flags' => $flags,
						'created' => time(),
						'expired' => $timeAdmin,
					]); 
				} else {
					
					#Сверяем флаги, если он активирует ту же услугу - продливаем её, если нет - активируем новое время
					if( $getVipUsersSite[0]['custom_flags'] == $flags  ) {
						$timeAdmin = $getVipUsersSite[0]['expired'] + $vip_days[$vip_server_days] * 97400;
					} else {
						$timeAdmin = time() + $vip_days[$vip_server_days] * 97400;
					}
					
					vip_users::update(
						[
							'custom_flags' => $flags,
							'expired' => $timeAdmin,
						],
						[
							'user_id' => $_SESSION['id'],
							'amx_id' => $insertAdmin,
							'server_id' => $vip_servers['amx_id'],							
						]
					);	
				}
				
				$getAmmxPrava = admins_servers::getAmxAdmin( 
					[ 
						'admin_id' => $insertAdmin,
						'server_id' => $vip_servers['amx_id'],
					],
					$host,
					$user,
					$password,
					$bd,
					$prefix
				);
				#проверяем права 
				if( !$getAmmxPrava ) {
					#Создаем ему права на сервере
					$admins_servers = admins_servers::addAmxBans( 
						[ 
							'admin_id' => 				$insertAdmin,
							'server_id' => 				$vip_servers['amx_id'],
							'custom_flags' =>			$flags,
							'use_static_bantime' => 	'yes',
						],
						$host,
						$user,
						$password,
						$bd,
						$prefix
					);
				} else { 
					#Обновляем ему флаги
					admins_servers::updateAmxAdmin(
						[ 'custom_flags' => $flags ],
						[ 'admin_id' => $insertAdmin, 'server_id' => $vip_servers['amx_id'] ],
						$host,
						$user,
						$password,
						$bd,
						$prefix	
					);
				}
				#обновляем деньги пользователя
				users::update(
					[
						'money' => $getUserMoney[0]['money'] - $allConst
					],
					[ 'id' => $_SESSION['id'] ]
				);
				#записываем в логи
				money_logs::insert([
					'user_id' => $_SESSION['id'],
					'tupe' => '1',
					'money' => $allConst,
					'title' => 'За активацию привилегий',
				]);
				
				$_SESSION['msg'] = 'Вы успешно активировали Вип, теперь Вам необходимо прописать в консоль игры перед входом игру setinfo "_pw" "Ваш пароль от панели"';
				return ADDRESS.'vip/success';
			}
			$_SESSION['err_msg'] = 'Вам не хватает денег '.$getUserMoney[0]['money'];
			return ADDRESS.'vip/';
		} else if( $vip_servers['type'] == '1' ) { 
			if( $getUserMoney[0]['money'] >= $allConst ) {
				#Получаем данные подключения
				$ftp_server = $vip_servers['host'];
				$user = $vip_servers['user'];
				$password = $vip_servers['password'];
				$bd = $vip_servers['bd']; 
				$prefix = $vip_servers['prefix'];

				// устанавливает соединение или выходит
				$conn_id = ftp_connect( $ftp_server ); 
				if( $conn_id ) {
					if ( ftp_login( $conn_id, $user, $password ) ) 
					{ 
						if (!ftp_get($conn_id, 'upload/users.ini', $bd, FTP_BINARY)) {
							$_SESSION['err_msg'] = 'Не удалось поключиться к файлу настройки сервера';
							return ADDRESS.'vip/';
						}
						
						#Получаем всех юзеров с сервера
						$getAllUsersServer = vip_users::select([
							'server_id' => $vip_servers['id']
						]);
						$formateUsers = '';
						for( $i = 0; $i < count( $getAllUsersServer ); $i++ ) {
							
							#Получаем юзера
							$getUserName = $this->sql->select(
								'users',
								[ 'username','password'  ],
								[ 'id' => $getAllUsersServer[$i]['user_id'] ]
							);
							
							$formateUsers .= "\"".$getUserName[0]['username']."\" \"".$getUserName[0]['password']."\" \"".$getAllUsersServer[$i]['custom_flags']."\" \"a\" ;Автоматическое добавление, конец админки ".$getAllUsersServer[$i]['timeAgo']."\n";
						}
						
						$of = fopen( 'upload/users.ini', "w+"); 
						$line=fgets( $of ); 
						rewind( $of ); 
						fwrite( $of, $formateUsers );
						fclose($of);
						
						
						$fp = fopen( 'upload/users.ini', 'r' );
						#Загружаем новый файл на сервер
						if ( !ftp_fput( $conn_id, $bd, $fp, FTP_ASCII ) ) {
							ftp_close( $conn_id );
							fclose($fp);
							$_SESSION['err_msg'] = 'Ошибка сохраненнии прав, обратитесь к администратору и сообщите ему об этом';
							return ADDRESS.'vip';
						}
						ftp_close( $conn_id );
						fclose($fp);
						
						$getVipUsersSite = vip_users::select([
							'user_id' => $_SESSION['id'],
							'server_id' => $vip_servers['id'],
						]);
				
						if( !$getVipUsersSite ) {
							#добавляем пользователя
							$timeAdmin = time() + $vip_days[$vip_server_days] * 97400;
							vip_users::insert([
								'user_id' => $_SESSION['id'],
								'amx_id' => '0',
								'server_id' => $vip_servers['id'],
								'custom_flags' => $flags,
								'created' => time(),
								'expired' => $timeAdmin,
							]);
						} else {
							#Сверяем флаги, если он активирует ту же услугу - продливаем её, если нет - активируем новое время
							if( $getVipUsersSite[0]['custom_flags'] == $flags  ) {
								$timeAdmin = $getVipUsersSite[0]['expired'] + $vip_days[$vip_server_days] * 97400;
							} else {
								$timeAdmin = time() + $vip_days[$vip_server_days] * 97400;
							}
							
							//$timeAdmin = $getVipUsersSite[0]['expired'] + $vip_days[$vip_server_days] * 97400;
							vip_users::update(
								[
									'custom_flags' => $flags,
									'expired' => $timeAdmin,
								],
								[
									'user_id' => $_SESSION['id'],
									'server_id' => $vip_servers['id'],							
								]
							);	
						}	 
						
						#обновляем деньги пользователя
						users::update(
							[
								'money' => $getUserMoney[0]['money'] - $allConst
							],
							[ 'id' => $_SESSION['id'] ]
						);
						#записываем в логи
						money_logs::insert([
							'user_id' => $_SESSION['id'],
							'tupe' => '0',
							'money' => $allConst,
							'title' => 'За активацию привилегий',
						]);

						$_SESSION['msg'] = 'Вы успешно активировали Вип, теперь Вам необходимо прописать в консоль игры перед входом игру setinfo "_pw" "Ваш пароль от панели"';
						return ADDRESS.'vip/success';
					} 
					$_SESSION['err_msg'] = 'Ошибка в настройках сервера.. не верный логин и пароль';
					return ADDRESS.'vip';
				}
				$_SESSION['err_msg'] = 'Ошибка в подключении к серверу';
				return ADDRESS.'vip';
			}
			$_SESSION['err_msg'] = 'Вам не хватает денег , пополните счет';
			return ADDRESS.'vip/';
		}
		
		
		$_SESSION['err_msg'] = 'Ошибка! Активации вип, тип сервера не настроен, сообщите администратору';
		return ADDRESS;
		
	}
	
	private function getPrava( $id, $number ) {
		#получаем группу юзера
		$getUserGroup = $this->sql->select(
			'users',
			[ 'group' ],
			[ 'id' => $id ]
		);	
		#Проверяем права, если он не рот админ - посылаем в лес) 
		if( $getUserGroup[0]['group'] == $number ) {
			return true;
		}	

		return false;		
	}
	
	public function addServerVip( $method ) {

		if( empty( $method ) ) {
			$_SESSION['err_msg'] = 'Не могу найти метод';
			return ADDRESS;
		}
		if( !$this->getPrava( $_SESSION['id'], 4 ) ) {
			$_SESSION['err_msg'] = 'Нету прав для добавления';
			return ADDRESS;
		}

		$type = $_POST['type'];
		$host = $_POST['host'];
		$user =  $_POST['user'];
		$password = $_POST['password'];
		$bd = $_POST['bd'];
		$prefix = $_POST['prefix'];
		$amx_id = $_POST['amx_id'];
		$server_name = $_POST['server_name']; 
		$server_ip = $_POST['server_ip'];
		$server_port =  $_POST['server_port'];
		
		if( !is_numeric( $type ) || empty( $host ) ||  empty( $user ) || empty( $password ) || empty( $bd ) || empty( $server_ip ) || empty( $server_name ) || !is_numeric( $server_port ) ) {
			$_SESSION['err_msg'] = 'Заполните все поля';
				
			return ADDRESS.'vip/admin/';	
		}
		
		if( $method == 'insert' ) {
			$insert = vip_servers::insert([
					'type' => $type,
					'host' => $host,
					'user' => $user,
					'password' => $password,
					'bd' => $bd,
					'prefix' => $prefix,
					'amx_id' => $amx_id,
					'server_name' => $server_name,
					'server_ip' => $server_ip,
					'server_port' => $server_port,
			]);
			if( !$insert ) {
				$_SESSION['err_msg'] = 'Ошибка добавления сервера';
					
				return ADDRESS.'vip/admin/';	
			}
				
			return ADDRESS.'vip/admin/?id='.$insert;
		} else if( $method == 'update' ) {
			if( !is_numeric( $_POST['refresh_server_vip'] ) ) {
				$_SESSION['msg'] = 'Ошибка обновления сервера.. не могу найти ID';
				return ADDRESS.'vip/admin/';	
			}
			$id = ( int ) $_POST['refresh_server_vip'];
			$privileg_data = !empty( $_POST['privileg_data'] ) ? $_POST['privileg_data'] : '';
			
			if( is_array( $privileg_data ) ) {
				$z = 0;
				foreach( $privileg_data as $key => $value ) {
					$newData[$z]['title'] = $value['title'];
					$newData[$z]['flags'] = $value['flags'];
					$newData[$z]['const'] = $value['const'];
					$z++;
				}
			} else {
				$newData = '';
			}
			$update = vip_servers::update(
				[
					'type' => $type,
					'host' => $host,
					'user' => $user,
					'password' => $password,
					'bd' => $bd,
					'prefix' => $prefix,
					'amx_id' => $amx_id,
					'server_name' => $server_name,
					'server_ip' => $server_ip,
					'server_port' => $server_port,		
					'privileg_data' => serialize( $newData ),		
				],
				[ 'id' => $id ]
			);
			if( !$update ) {
				$_SESSION['msg'] = 'Ошибка обновления сервера.. ';
				return ADDRESS.'vip/admin/';	
			}
			$_SESSION['msg'] = 'Сервер успешно обновлен';
			return ADDRESS.'vip/admin/?id='.$id;
		}
		
		$_SESSION['err_msg'] = 'Ошибка';
		return ADDRESS.'vip/admin/';

	}
	
	public function seendDeleteBan( $id ) {
		if( !isset( $_SESSION['id'] ) ) {
			$this->rJson( [ 'status' => 0 ] );
		}
		if( !is_numeric( $id ) )
			$this->rJson( [ 'status' => 0 ] );		
			
		#получаем группу юзера
		$getUserGroup = $this->sql->select(
			'users',
			[ 'group' ],
			[ 'id' => $_SESSION['id'] ]
		);
			
		#Проверяем права
		if( $getUserGroup[0]['group'] == 3 ||  $getUserGroup[0]['group'] == 4 ) {
			bans::delete( [ 'bid' => $id ] ); //удаляем бан
			$this->rJson( [ 'status' => 1 ] );
		}
			
		$this->rJson( [ 'status' => 0 ] );	
	}
	
	
	public function seendZayavkaBans( $id ) {
		if( !isset( $_SESSION['id'] ) ) {
			$this->rJson( [ 'status' => 0 ] );
		}
		if( !is_numeric( $id ) )
			$this->rJson( [ 'status' => 0 ] );		
		
		$getBan = bans::select( '*', [ 'bid' => $id ] );
		
		if( !is_array( $getBan ) ) 
			$this->rJson( [ 'status' => 0 ] );
		
		$bid = $getBan[0]['bid'];
		
		$player_nick = $getBan[0]['player_nick'];
		$admin_nick = $getBan[0]['admin_nick'];
		
		$ban_reason = !empty( $getBan[0]['ban_reason'] ) ? $getBan[0]['ban_reason'] : $getBan[0]['cs_ban_reason'];
		
		$ban_created = times::formatDate( $getBan[0]['ban_created'] );
		$expired = $getBan[0]['expired'];
		$server_name = $getBan[0]['server_name'];
		
		$content = "Здравствуйте, прошу разбанить меня {$player_nick} 
		На сервере {$server_name}
		Меня забанили {$ban_created}
		Меня забанил админ {$admin_nick}
		По причине {$ban_reason}
		(Сообщение сгенерировано автоматически)";
		
		$sql = $this->sql->insert(
			'forum_theards',
			[
				'title' => 'Заявка на разбан от '.$getBan[0]['player_nick'],
				'content' => trim( $content ),
				'created' => time(),
				'autor_id' => $_SESSION['id'],
				'forum_id' => AMXBANS_FORUM,
				'this_liked' => serialize( [] ),
				'last_post' => time(),
			]
		);
		$this->rJson( [ 'status' => $sql ] );
	}
	public function searchBans( $queri ) {
		$class = '';
		$data = '';
		$banList = bans::search( $queri );
		if( is_array( $banList ) ) {
			for( $i = 0; $i < count( $banList ); $i++ ) {
				include( 'theme/bans/table_ittem.tpl' );
			}
		}
		exit();
	}
	
	public function deleteReplie( $id ) { 
		
		if( !isset( $_SESSION['id'] ) ) 
			exit();

		if( !is_numeric( $id ) )
			exit();		
		
		$id = ( int ) $id;
		
		$forum_replay = $this->sql->select(
			'forum_replay',
			[ 'autor_id', 'theard_id' ],
			[ 'id' => $id ]
		);
		

		if( !is_array( $forum_replay ) ) {
			$data = [ 
				'status' => 1,
				'msg' => 'Ошибка  удааления',
			];
			
			$this->rJson( $data );	
		}

		#получаем группу юзера
		$getUserGroup = $this->sql->select(
			'users',
			[ 'group' ],
			[ 'id' => $_SESSION['id'] ]
		);
			
		#Проверяем права
		if( ( $getUserGroup[0]['group'] == 3 ||  $getUserGroup[0]['group'] == 4 ||  $getUserGroup[0]['group'] == 2 ) || ( $_SESSION['id'] == $forum_replay[0]['autor_id'] ) ) {
			
			$getTheard = $this->sql->select(
				'forum_theards',
				[ 'count_replay' ],
				[ 'id' => $forum_replay[0]['theard_id'] ]
			);
			
			$this->sql->update(
				'forum_theards',
				[ 'count_replay' => ( $getTheard[0]['count_replay'] - 1 ) ],
				[ 'id' => $forum_replay[0]['theard_id'] ]
			);
			
			$this->sql->delete(
				'forum_replay',
				[ 'id' => $id ]
			);
			
			$getUserData = $this->sql->select( 
				'users',
				[ 'id', 'count_post' ],
				[ 'id' => $forum_replay[0]['autor_id'] ]
			);
			if( $getUserData[0]['count_post'] != 0 ) {
				users::update( 
					[ 'count_post' => $getUserData[0]['count_post'] - 1 ], 
					[ 'id' => $forum_replay[0]['autor_id'] ]
				);
			}
			$data = [ 
					'status' => 200,
			];
			
			$this->rJson( $data );				
		}
		exit();
	}
	
	public function theardLike( $theard_lite, $table ) {
		if( !isset( $_SESSION['id'] ) ) 
			return ADDRESS;
		
		if( !is_numeric( $theard_lite ) )
			return ADDRESS;	
		#Фикс на получение таблицы ИД админов
		$getAutorTable = ( $table == 'forum_replay' ) ? 'autor_id' : 'autor_id';
		
		$getTheard = $this->sql->select(
			$table,
			[ 'this_liked', 'autor_id' ],
			[ 'id' => $theard_lite ]
		);
		if( !is_array( $getTheard ) ) {
			$data = [ 
				'status' => 1,
				'msg' => 'Темы не существует',
			];
			
			$this->rJson( $data );	
		}
		
		$this_liked = unserialize( $getTheard[0]['this_liked'] ); 
		if( in_array( $_SESSION['id'], $this_liked) ) {
			$data = [ 
				'status' => 1,
				'msg' => 'Вы уже лайкали ',
			];
			
			$this->rJson( $data );				
		}
		
		$this_liked[] = $_SESSION['id']; 
		
		#Ищем юзера 
		/*
		$getUserData = users::getId( $getTheard[0]['autor_id'] );
		*/
		#Ищем юзера 
		$getUserData = $this->sql->select( 
			'users',
			[ 'id', 'count_like' ],
			[ 'id' => $getTheard[0]['autor_id'] ]
		);
		
		users::update( 
			[ 'count_like' => $getUserData[0]['count_like'] + 1 ], 
			[ 'id' => $getUserData[0]['id'] ]
		);
		$this->sql->update(
			$table, 
			[ 'this_liked' =>  serialize( $this_liked ) ],
			[ 'id' => $theard_lite ]
		);

		$data = [ 
			'status' => 200,
		];
		
		$this->rJson( $data );
	}
	
	
	public function deleteTheard( $id, $method, $tupe ) {
		if( !isset( $_SESSION['id'] ) ) 
			return ADDRESS;
		
		if( !is_numeric( $tupe ) )
			return ADDRESS;	
		
		if( !is_numeric( $id ) )
			return ADDRESS;
		
		if( $tupe == 0 || $tupe == 1) {
			
			$id = ( int ) $id;
			$tupe = ( int ) $tupe;
			
			#получаем группу юзера
			$getUserGroup = $this->sql->select(
				'users',
				[ 'group' ],
				[ 'id' =>$_SESSION['id'] ]
			);
			
			#Проверяем права
			if( $getUserGroup[0]['group'] == 3 ||  $getUserGroup[0]['group'] == 4 ||  $getUserGroup[0]['group'] == 2 ) {
				if( $method == 'delete' ) {
					#удаляем, просто меняем значение темы deleted на 1
					$this->sql->update(
						'forum_theards',
						[ 'deleted' => $tupe ],
						[ 'id' => $id ]
					);
					if( $tupe == 1) {
						$_SESSION['msg'] = 'Тема успешно удалена';
					} else {
						$_SESSION['msg'] = 'Тема успешно восстановлена';
					}
					
				}
				if( $method == 'status' ) {
					#Меняем статус темы значение темы status на 1
					$this->sql->update(
						'forum_theards',
						[ 'status' => $tupe ],
						[ 'id' => $id ]
					);
					if( $tupe == 1) {
						$_SESSION['msg'] = 'Тема успешно закреплена';
					} else {
						$_SESSION['msg'] = 'Тема успешно откреплена';
					}
					
				}
				if( $method == 'closed' ) {
					#Меняем статус темы значение темы closed на 1
					$this->sql->update(
						'forum_theards',
						[ 'closed' => $tupe ],
						[ 'id' => $id ]
					);
					if( $tupe == 1) {
						$_SESSION['msg'] = 'Тема успешно была закрыта';
					} else {
						$_SESSION['msg'] = 'Тема успешно была открыта';
					}
					
				}
				return ADDRESS.'forum/topic?id='.$id;
			}
		}
		return ADDRESS;
		
	}
	
	public function readTheard( $table, $post, $msg ) {
		if( !isset( $_SESSION['id'] ) ) 
			exit();
		
		if( !is_numeric( $post ) ) {
			$data = [ 
				'status' => 1,
				'msg' => 'Произоша ошибка... Сообщите администратору',
			];
			
			$this->rJson( $data );		
		}
		
		$theard = ( int ) $post;
		//$read_theard =  $_POST['read_theard'];
		$read_theard = $msg;
		
		if( empty( $read_theard ) ) {
			$data = [ 
				'status' => 1,
				'msg' => 'Пустое сообщение',
			];	
			$this->rJson( $data );
		}
		
		$getTheard = $this->sql->select(
			$table,
			'*',
			[ 'id' => $theard ]
		);


		if( !is_array( $getTheard ) ) {
			$data = [ 
				'status' => 1,
				'msg' => 'Темы не существует',
			];
			
			$this->rJson( $data );		
		}
		
		#получаем группу юзера
		$getUserGroup = $this->sql->select(
			'users',
			[ 'group' ],
			[ 'id' =>$_SESSION['id'] ]
		);
		//$autor = ( $table == 'forum_replay' ) ? 'autor_id' : 'autor';
		if( $getTheard[0]['autor_id'] == $_SESSION['id'] || $getUserGroup[0]['group'] == 3 || $getUserGroup[0]['group'] == 4 || $getUserGroup[0]['group'] == 2 ) {
			#обновляем тему
			$update = $this->sql->update(
				$table,
				[ 'content' => trim( $read_theard ) ],
				[ 'id' => $theard ]
			);
			if( $update ) {
				$data = [ 
					'status' => 200,
					'post' =>  func::bcod(htmlspecialchars( trim( $read_theard ) ) ),
				];				
			} else {
				$data = [ 
					'status' => 1,
					'msg' => 'При обновлении произошла ошибка.. Обратитесь к администратору',
				];	
			}
		} else {
			$data = [ 
				'status' => 1,
				'msg' => 'У вас недостаточно прав для этого',
			];				
		}

			
		$this->rJson( $data );
	}
	
	public function postmessegeTopic() {
		if( !isset( $_SESSION['id'] ) ) 
			exit();
		
		if( !is_numeric( $_POST['theard'] ) ) {
			$data = [ 
				'status' => 1,
				'msg' => 'Произоша ошибка... Сообщите администратору',
			];
			
			$this->rJson( $data );		
		}
		$theard = ( int ) $_POST['theard'];
		$content =  trim( $_POST['content'] );
		
		if( !isset( $content ) ||  empty( $content) ) {
			$data = [ 
				'status' => 1,
				'msg' => 'Заполните собщение',
			];
			
			$this->rJson( $data );	
		}
		
		$getTheard = $this->sql->select(
			'forum_theards',
			'*',
			[ 'id' => $theard ]
		);
		
		if( !is_array( $getTheard ) ) {
			$data = [ 
				'status' => 1,
				'msg' => 'Темы не существует',
			];
			
			$this->rJson( $data );		
		}
		
		$sql = $this->sql->insert(
			'forum_replay',
			[
				'theard_id' => $theard,
				'autor_id' => $_SESSION['id'],
				'content' => $content,
				'created' => time(),
				'this_liked' => serialize( [] ),
			]
		);
		
		$this->sql->update(
			'forum_theards',
			[ 
				'count_replay' => ( $getTheard[0]['count_replay'] + 1),
				'last_post' => time()
			],
			[ 'id' => $theard ]
		);
		
		$getUserData = $this->sql->select( 
			'users',
			[ 'id', 'count_post' ],
			[ 'id' => $_SESSION['id'] ]
		);
		
		users::update( 
			[ 'count_post' => $getUserData[0]['count_post'] + 1 ], 
			[ 'id' => $_SESSION['id'] ]
		);
		
		if( $sql ) {
			$data = [ 
				'status' => 200,
				'post_id' => $sql,
				'content_bb' => func::bcod( htmlspecialchars( trim(  $content ) ) ),
				'content' => htmlspecialchars( trim(  $content ) ),
			];		
		} else {
			$data = [ 
				'status' => 1,
				'msg' => 'Ошибка отправки сообщения',
			];	
		}
		$this->rJson( $data );	
	} 
	
	
	public function createTheard() {
		if( !isset( $_SESSION['id'] ) )
			return ADDRESS;		
		$create_theard = isset( $_POST['create_theard'] ) ? $_POST['create_theard'] : '';
		$r = ADDRESS.mb_substr( $create_theard, 1);
		
		$category = $_POST['category'];
		$content = trim( $_POST['content'] );
		$title = trim( $_POST['title'] );

		if( !is_numeric( $category ) ) {
			$_SESSION['err_msg'] = 'Ошибка создания топика';
			return $r;
		}

		if( !isset( $content ) ||  empty( $content) ) {
			$_SESSION['err_msg'] = 'Заполните собщение';
			return $r;		
		}
		
		if( !isset( $title ) ||  empty( $title) ) {
			$_SESSION['err_msg'] = 'Заполните название топика';
			return $r;		
		}
		
		$sql = $this->sql->insert(
			'forum_theards',
			[
				'title' => $title,
				'content' => $content,
				'created' => time(),
				'autor_id' => $_SESSION['id'],
				'forum_id' => ( int ) $category,
				'this_liked' => serialize( [] ),
				'last_post' => time(),
			]
		);

		$getUserData = $this->sql->select( 
			'users',
			[ 'id', 'count_theard' ],
			[ 'id' => $_SESSION['id'] ]
		);

		$count_theard = $getUserData[0]['count_theard'] + 1;

		/*
		users::update( 
			[ 'count_theard' => $count_theard ], 
			[ 'id' => $_SESSION['id'] ]
		);
		*/
		$this->sql->update(
			'users',
			[ 'count_theard' => $count_theard ],
			[ 'id' => $_SESSION['id'] ]
		);
		if( $sql ) {
			$_SESSION['msg'] = 'Тема успешно создана';
			return ADDRESS.'forum/topic?id='.$sql;
		}
		$_SESSION['err_msg'] = 'ошибка создания темы.. Обратитесь к администратору';
		return $r;
	}
	
	public function vkAutch( $code ) {
		if( isset( $_SESSION['id'] ) )
			return ADDRESS;
		
		if ( isset( $_GET['code'] ) ) {
			$redirect_uri = ADDRESS.'function.php?vk_autch=true';
			$params = array(
				'client_id' => VK_APP_ID,
				'client_secret' => VK_APP_KEY,
				'code' => $_GET['code'],
				'redirect_uri' => $redirect_uri
			);
			
			$token = json_decode(file_get_contents('https://oauth.vk.com/access_token' . '?' . urldecode(http_build_query($params))), true);

			if (isset($token['access_token'])) {
				$getUser = $this->sql->select(
					'users',
					'*',
					[ 'vk_id' => $token['user_id'] ]
				);
				if( is_array( $getUser[0] ) ) {
					$userid = md5( $getUser[0]['username'].':'.$getUser[0]['email'].':'.time() );
					$this->sql->update(
						'users',
						[ 
							'vk_id' => $token['user_id'],
							'access_token' => $token['access_token'],
							'userid' => $userid,
						],
						[ 'id' => $getUser[0]['id'] ]
					);	
					$addUser = $getUser[0]['id'];
				} else {

					
					$params = array(
						'uids'         => $token['user_id'],
						'fields'       => 'uid,first_name',
						'access_token' => $token['access_token']
					);

					$userInfo = json_decode(file_get_contents('https://api.vk.com/method/users.get' . '?' . urldecode(http_build_query($params))), true);
					
					if (isset($userInfo['response'][0]['uid'])) {
						$userInfo = $userInfo['response'][0];
						$result = true;
					}
					
					if( $result ) {
						$userid = md5( $userInfo['first_name'].':'.$userInfo['uid'].':'.time() );
						$ppassword = rand( 10000, 999999);
						
						#создаем юзера
						$addUser = $this->sql->insert(
							'users',
							[
								'username' => $userInfo['first_name'].' '.$userInfo['last_name'],
								'password' => $ppassword,
								'group' => '0',
								'money' => '0',
								'email' => '',
								'vk_id' => $userInfo['uid'],
								'userid' => $userid,
								'reg_data' => time(),
								'access_token' => $token['access_token']
							]
						);
						$_SESSION['msg'] = 'Мы создали Вам аккаунт, Ваш пароль '.$ppassword;						
					}

				}
				#убиваем все сессии
				$this->logOut( false );	
				
				SetCookie( 'userid',  $userid, time() + 2592000 );
				$_SESSION['id'] = $addUser;
			}
		}
		return ADDRESS;
	}
	
	public function changeavatar() {
		if( !isset( $_SESSION['id'] ) ) 
			exit();
		
		if( !is_array( $_FILES['changeavatar'] ) )
			exit();
		$getUser = $this->sql->select(
			'users',
			[ 'avatar' ],
			[ 'id' => $_SESSION['id'] ]
		);
		
		//проверяем наличие старой аватары
		if( !is_array( $getUser ) ) {
			$data = [ 
				'status' => 1,
				'msg' => 'Ошибка загрузки аватара',
			];
			
			$this->rJson( $data );
		}
		
		#загружаем аватар
		$changeavatar = $this->uploadFile( $_FILES['changeavatar'] );
		
		if( $changeavatar ) {
			#обновляем аваратку
			$this->sql->update(
				'users',
				[ 'avatar' => $changeavatar ],
				[ 'id' => $_SESSION['id'] ]
			);
			#Если это не стандартный аватар - удаляем
			if( $getUser[0]['avatar'] != 'public/img/avatars/avatar11_big.png' ) {
				//Удаляем стару аватару
				unlink( $getUser[0]['avatar'] );			
			}
			$data = [ 
				'status' => 200,
				'url' => $changeavatar
			];			
		} else {
			$data = [ 
				'status' => 1,
				'url' => 'Ошибка загрузки аватара'
			];			
		}
		
		$this->rJson( $data );
	}
	
	public function setting() {
		if( !isset( $_SESSION['id'] ) ) 
			return ADDRESS;
		
		$settingPost = isset( $_POST['setting'] ) ? $_POST['setting'] : 'q';
		$r = ADDRESS.mb_substr( $settingPost, 1);	
		
		$username = $_POST['username'];
		$email = $_POST['email'];
		$password = $_POST['password'];
		$addUpdate = [];
		
		if( is_array( $username ) ||  is_array( $email )  ||  is_array( $password ) ) {
			$_SESSION['err_msg'] = 'Массив запрещен';
			return $r;			
		}
		
		if( empty( $username ) ) {
			$_SESSION['err_msg'] = 'Напишите свой ник';
			return $r;
		}
		if( empty( $email ) ) {
			$_SESSION['err_msg'] = 'Напишите свою почту';
			return $r;
		}
		
		if( mb_strlen( $username ) > 32 || mb_strlen( $username ) < 1 ) {
			$_SESSION['err_msg'] = 'Логин должен содержать больше 1 символа и максимум 32';
			return $r;
		}
		
		if( !filter_var( $email, FILTER_VALIDATE_EMAIL ) ){ 
			$_SESSION['err_msg'] = 'Почта заполнена не верно';
			return $r;
		}
		
		
		if( empty( $password ) ) {
			$_SESSION['err_msg'] = 'Введите свой пароль';
			return $r;			
		}
		
		#Получаем данные юзера
		$getUserSes = $this->sql->select(
			'users',
			[ 'username', 'email', 'password' ],
			[ 'id' => $_SESSION['id'], ]
		);
		
		if( $getUserSes[0]['password'] != $password ) {
			#Создаем массив и добавляем пароль
			$addUpdate['password'] = $password;
			
			$getSErvers = $this->sql->select(
				'vip_users',
				'*',
				[ 'user_id' => $_SESSION['id'] ]
			); 
			
			
			#Если есть сервера
			if( is_array( $getSErvers ) ) {
				for( $i = 0; $i < count( $getSErvers ); $i++ ){
					
					$serverList = vip_servers::getIdAdmin( $getSErvers[$i]['server_id'] );
					
					#Берем сервера только AmxAdmins
					if( $serverList['type'] == '0' ) {
						#подготавливаем данные сервера
						$hostAmx = $serverList['host'];
						$userAmx = $serverList['user'];
						$passwordAmx = $serverList['password'];
						$bdAmx = $serverList['bd'];
						$prefixAmx = $serverList['prefix'];
						
						amxadmins::updateAmxAdmin(
							[ 'password' => md5( $password ) ],
							[ 'id' => $getSErvers[$i]['amx_id'] ],
							$hostAmx, $userAmx, $passwordAmx,  $bdAmx, $prefixAmx
						);
						
					}
				}
			}
		}
		
		$getUser = $this->sql->select(
			'users',
			[ 'id', 'username' ],
			[ 'username' => $username, ]
		);
		
		#Добавляем в массив новый ник
		if( !is_array( $getUser ) ) {
			$addUpdate['username'] = $username;
		}
		
		$getEmail = $this->sql->select(
			'users',
			[ 'id', 'email' ],
			[ 'email' => $email, ]
		);
		
		#Добавляем в массив новую почту если она не занята
		if( !is_array( $getEmail ) ) {
			$addUpdate['email'] = $email;
		}
		$update = $this->sql->update(
			'users',
			$addUpdate,
			[ 'id' => $_SESSION['id'] ]
		);
		if( $update )
			$_SESSION['msg'] = 'Настройки сохранены';	
		else 
			$_SESSION['err_msg'] = 'Ошибка сохранения данных';
		return $r;
	}
	
	public function autch() {
		if( isset( $_SESSION['id'] ) ) 
			return ADDRESS;
		$registerPost = isset( $_POST['register'] ) ? $_POST['register'] : 'q';
		$r = ADDRESS.mb_substr( $registerPost, 1);
		$auth_name = $_POST['auth_name'];
		//$auth_password = md5( $_POST['auth_password'] );
		$auth_password = $_POST['auth_password'];
		
		if( filter_var( $auth_name, FILTER_VALIDATE_EMAIL ) ){ 
			$where = [ 
				'email' => $auth_name,
				'password' => $auth_password,
			];
		} else {
			$where = [ 
				'username' => $auth_name, 
				'password' => $auth_password,
			];
		}
		
		$check = $this->sql->select(
			'users',
			[ 'id', 'username', 'email' ],
			$where
		);
		
		if( !is_array( $check ) ) {
			$_SESSION['err_msg'] = 'Не верный логин или пароль.. попробуйте еще';
			return $r.'register';
		}
		$userid = md5( $check[0]['username'].':'.$check[0]['email'].':'.time() );
		$this->sql->update(
			'users',
			[ 'userid' => $userid ],
			[ 'id' => $check[0]['id'] ]
		);
		$_SESSION['id'] = $check[0]['id'];
		SetCookie( 'userid',  $userid, time() + 2592000 );
		return $r;
	}
	
	public function register() {
		if( isset( $_SESSION['id'] ) ) 
			return ADDRESS;
		//$r = ADDRESS.mb_substr( $_POST['register'], 1);
		$registerPost = isset( $_POST['register'] ) ? $_POST['register'] : 'q';
		$r = ADDRESS.mb_substr( $registerPost, 1);
		$username = $_POST['username'];
		$email = $_POST['email'];
		$password = $_POST['password'];
		$password2 = $_POST['password2'];
		$_SESSION['username'] = htmlspecialchars( $username );
		$_SESSION['email'] = htmlspecialchars( $email );
		
		if( is_array( $username ) ||  is_array( $email )  ||  is_array( $password )   ||  is_array( $password2 ) ) {
			$_SESSION['err_msg'] = 'Массив запрещен';
			return $r;			
		}
		
		if( empty( $username ) ) {
			$_SESSION['err_msg'] = 'Напишите свой ник';
			return $r;
		}
		if( empty( $email ) ) {
			$_SESSION['err_msg'] = 'Напишите свою почту';
			return $r;
		}
		if( empty( $password ) &&   empty( $password2 ) ) {
			$_SESSION['err_msg'] = 'Напишите свой пароль';
			return $r;
		}
		if( $password !=  $password2 ) {
			$_SESSION['err_msg'] = 'Пароли не совпадают';
			return $r;
		}
		if( mb_strlen( $username ) > 32 || mb_strlen( $username ) < 1 ) {
			$_SESSION['err_msg'] = 'Логин должен содержать больше 1 символа и максимум 32';
			return $r;
		}
		
		if( !filter_var( $email, FILTER_VALIDATE_EMAIL ) ){ 
			$_SESSION['err_msg'] = 'Почта заполнена не верно';
			return $r;
		}
		
		$getUser = $this->sql->select(
			'users',
			[ 'id' ],
			[ 'username' => $username, ]
		);
		
		if( is_array( $getUser ) ) {
			$_SESSION['err_msg'] = 'Данный ник уже зарегистрирован';
			unset( $_SESSION['username'] );
			return $r;			
		}
		$getMail = $this->sql->select(
			'users',
			[ 'id' ],
			[ 'email' => $email, ]
		);
		
		if( is_array( $getMail ) ) {
			$_SESSION['err_msg'] = 'Данная почта уже занята';
			unset( $_SESSION['email'] );
			return $r;			
		}
		
		$userid = md5( $username.':'.$email.':'.time() );
		
		#создаем юзера
		$addUser = $this->sql->insert(
			'users',
			[
				'username' => $username,
				//'password' => md5( $password ),
				'password' => $password,
				'group' => '0',
				'money' => '0',
				'email' => $email,
				'vk_id' => '0',
				'userid' => $userid,
				'reg_data' => time(),
			]
		);
		#убиваем все сессии
		$this->logOut( false );
		#присваиваем куки и сессию
		SetCookie( 'userid',  $userid, time() + 2592000 );
		$_SESSION['id'] = $addUser;
		return $r;
	}
	
	public function logOut( $return = ADDRESS ) {
		if( is_array( $_SESSION ) ) {
			foreach ( $_SESSION as $key => $value ) {
				unset( $_SESSION[$key] );
			}
		}		
		SetCookie( 'userid',  '', 32600 );
		return $return;
	}
	
	public function uploadFile( $fileValue ) {
		if( !isset( $_SESSION['id'] ) ) {
			die('Что-то тут не так..)');
		} 
		if( 
			$fileValue['type'] == 'image/jpeg' || 
			$fileValue['type'] == 'image/png' 
		) {
		 
			if( $fileValue["size"] > 1024*3*1024 )
			{
				$_SESSION['msg'] = "Размер файла превышает три мегабайта";
				return false;
			}
			if( is_uploaded_file( $fileValue["tmp_name"] ) )
			{
				$fileFormat = new SplFileInfo( $fileValue["name"] );
				$newFile = rand(99, 9999).time().'.'.$fileFormat->getExtension();
				
				if (! file_exists('upload/' . date('Y')))
				{
					mkdir('upload/' . date('Y'), 0777, true);
				}
				
				if (! file_exists('upload/' . date('Y') . '/' . date('m')))
				{
					mkdir('upload/' . date('Y') . '/' . date('m'), 0777, true);
				}
				
				$uploadDir = 'upload/' . date('Y') . '/' . date('m')."/";
				
				move_uploaded_file(
					$fileValue["tmp_name"], 
					$uploadDir.$newFile
				);
				
				
				return $uploadDir.$newFile;
			}
		}
		 else {
			$_SESSION['msg'] = "Загрузить можно только картинку.. jpg формата";
			return false;
		}
	}
	
	public function	redirect( $link ) {
		header( "Location: {$link}" );
		exit();
	}
	
	public function pre( $text ) {
		echo '<pre>';
		print_r( $text );
		die();
	}
	
	public function rJson( $data ) {
		header("Content-type: application/json; charset=utf-8");
		echo json_encode( $data );
		exit();		
	}
}
?>