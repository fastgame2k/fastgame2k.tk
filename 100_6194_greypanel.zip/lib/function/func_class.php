<?php

class func {
	static public function seoKey($contents,$symbol=5,$words=18){
		$contents = @preg_replace(array("'<[\/\!]*?[^<>]*?>'si","'([\r\n])[\s]+'si","'&[a-z0-9]{1,6};'si","'( +)'si"),
		array("","\\1 "," "," "),strip_tags($contents));
		$rearray = array("~","!","@","#","$","%","^","&","*","(",")","_","+",
							 "`",'"',"№",";",":","?","-","=","|","\"","\\","/",
							 "[","]","{","}","'",",",".","<",">","\r\n","\n","\t","«","»");

		$adjectivearray = array("ые","ое","ие","ий","ая","ый","ой","ми","ых","ее","ую","их","ым",
									"как","для","что","или","это","этих",
									"всех","вас","они","оно","еще","когда",
									"где","эта","лишь","уже","вам","нет",
									"если","надо","все","так","его","чем",
									"при","даже","мне","есть","только","очень",
									"сейчас","точно","обычно"
								);


		$contents = @str_replace($rearray," ",$contents);
		$keywordcache = @explode(" ",$contents);
		$rearray = array();

		foreach($keywordcache as $word){
			if(strlen($word)>=$symbol && !is_numeric($word)){
				$adjective = substr($word,-2);
				if(!in_array($adjective,$adjectivearray) && !in_array($word,$adjectivearray)){
					$rearray[$word] = (array_key_exists($word,$rearray)) ? ($rearray[$word] + 1) : 1;
				}
			}
		}

		@arsort($rearray);
		$keywordcache = @array_slice($rearray,0,$words);
		$keywords = "";

		foreach($keywordcache as $word=>$count){
			$keywords.= ",".$word;
		}

		return substr($keywords,1);
	}
	
	static public function bcod($text_post) {
	$str_search = array(
			"#\\\n#is",
			"#\[br/]#is",
			"#\[quote\](.+?)\[\/quote\]#is",
			"#\[quote\=(.+?)\](.+?)\[\/quote\]#is",
			"#\[img\](.+?)\[\/img\]#is",
			"#\[b\](.+?)\[\/b\]#is",
			"#\[url\](.+?)\[\/url\]#is",
			"#\[url\=(.+?)\](.+?)\[\/url\]#is",
		);
		$str_replace = array(
			"<br />",
			"<br />",
			"<blockquote class=\"content-list-wrapper\"><div>\\1</div></blockquote>",
			'<blockquote title="Цитата \\1" class="well content-list-wrapper"><i class="fa fa-quote-left"></i>  <b>\\1</b><i class="fa fa-quote-right"></i> пишет:  <p>\\2</p></blockquote>',
			"<img class='post_src' src='\\1' />",
			"<b>\\1</b>",
			"<a href='\\1'>\\1</a>",
			"<a href='\\2'>\\1</a>",
		);
		return preg_replace($str_search, $str_replace, $text_post);
	}	
	static public function seoTitle( $s )
	{
		$s = mb_strtolower( $s );
		$s = preg_replace( '#[^a-zа-я0-9]+#u', '-', $s );
		$s = trim($s, '-');
		return $s;
	} 
	
	static public function atranslit($text)
	{
		$find=array('А','а','Б','б','В','в','Г','г','Д','д','Е','е','Ё','ё','
		Ж','ж','З','з','И','и','Й','й','К','к','Л','л','М','м','
		Н','н','О','о','П','п','Р','р','С','с','Т','т','У','у','
		Ф','ф','Х','х','Ц','ц','Ч','ч','Ш','ш','Щ','щ','Ъ','ъ','
		Ы','ы','Ь','ь','Э','э','Ю','ю','Я','я');
		$replace=array('A','a','B','b','V','v','G','g','D','d','E','e','Yo','yo','
		Zh','zh','Z','z','I','i','J','j','K','k','L','l','M','m','
		N','n','O','o','P','p','R','r','S','s','T','t','U','u','
		F','f','H','h','Ts','ts','Ch','ch','Sh','sh','Sch','sch','','','','','','','E','e','Yu','yu','Ya','ya');
	 
		$text = str_replace($find, $replace,$text);
		
		$text = preg_replace ("/[^\w\d\s\_-]*/", "",$text);
		$text=str_replace(" ","-",$text);
		return $text;
	}

}
?>