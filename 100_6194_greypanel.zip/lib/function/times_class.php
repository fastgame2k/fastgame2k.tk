<?php

class times {
	
	//форматирование даты
	static public function formatDate($timestamp){
		$date=explode(".", date("H.i.d.m.Y года в H:i", $timestamp));
		switch ($date[3]){
			case 1: $m='Января'; break;
			case 2: $m='февраля'; break;
			case 3: $m='марта'; break;
			case 4: $m='апреля'; break;
			case 5: $m='мая'; break;
			case 6: $m='июня'; break;
			case 7: $m='июля'; break;
			case 8: $m='августа'; break;
			case 9: $m='сентября'; break;
			case 10: $m='октября'; break;
			case 11: $m='ноября'; break;
			case 12: $m='декабря'; break;
		}
		return $date[2].' '.$m.' '.$date[4].'';
	}

	//Времени назад	
	static public function timeAgo($time_ago)
	{
		$cur_time   = time();
		$time_elapsed   = $cur_time - $time_ago;
		$seconds    = $time_elapsed ;
		$minutes    = round($time_elapsed / 60 );
		$hours      = round($time_elapsed / 3600);
		$days       = round($time_elapsed / 86400 );
		$weeks      = round($time_elapsed / 604800);
		$months     = round($time_elapsed / 2600640 );
		$years      = round($time_elapsed / 31207680 );
		// Seconds
		if($seconds <= 60){
			return "Только что";
		}
		//Minutes
		else if($minutes <=60){
			if($minutes==1){
				return "1 минуту назад";
			}else if($minutes == 2 || $minutes == 3 || $minutes == 4){
				return "{$minutes} минуты назад";
			}
			else{
				return "$minutes минут назад";
			}
		}
		//Hours
		else if($hours <=24){
			if( $hours==1 ){
				return "1 час назад";
			}	else if($hours == 2 || $hours==3 || $hours==4 ){
				return "{$hours} часа назад";
			}else{
				return "$hours часов назад";
			}
		}
		//Days
		else if($days <= 7){
			if($days==1){
				return "1 день назад";
			}else if($days==2 || $days==3 || $days==4){
				return "{$days} дня назад";
			}else{
				return "$days дней назад";
			}
		}
		//Weeks
		else if($weeks <= 4.3){
			if($weeks==1){
				return "1 неделю назад";
			}else if( $weeks==2 || $weeks==3 || $weeks==4 ){
				return "{$weeks} недели назад";
			}else{
				return "$weeks недель назад";
			}
		}
		//Months
		else if($months <=12){
			if($months==1){
				return "1 месяц назад";
			}else if( $months == 2 || $months == 3  || $months == 4 ){
				return "{$months} месяца назад";
			}else{
				return "{$months} месяцев назад";
			}
		}
		//Years
		else{
			if($years==1){
				return "1 год назад";
			}else if( $years == 2 || $years == 3 || $years == 4 ){
				return "{$years} года назад";
			}else{
				return "{$years} лет назад";
			}
		}
		
		return "Ошибка функции времени";
	}

	//получить секунды
	static public function get_sec( $get_sec ) {
		$times = self::seconds2times($get_sec);
		$times_values = array('сек','мин','час','д','лет');
		for ($i = count($times)-1; $i >= 0; $i--)
		{
			return $times[$i] . ' ' . $times_values[$i] . ' ';
		}
	}
	
	static private function seconds2times($seconds)
	{
		$times = array();
		$count_zero = false;
		$periods = array(60, 3600, 86400, 31536000);
		
		for ($i = 3; $i >= 0; $i--)
		{
			$period = floor($seconds/$periods[$i]);
			if (($period > 0) || ($period == 0 && $count_zero))
			{
				$times[$i+1] = $period;
				$seconds -= $period * $periods[$i];
				
				$count_zero = true;
			}
		}
		
		$times[0] = $seconds;
		return $times;
	}
}
?>