<?php

class form {
	
	public $head;
	public $method;
	public $action;
	public $classForm;
	
	public function __construct( $array, $classForm, $head = "", $method = "POST",  $action = ADDRESS ) {
		if( !is_array( $array ) )
			return 'Ошибка формы, заполните все значения';
		
		$this->method = $method;
		$this->action = $action;
		$this->head = $head;
		$this->classForm = $classForm;
		$this->goForm( $array );
	}
	
	private function getReplaceContent( $sr, $file ) {
		$search = array();
		$replace = array();
		$i = 0;
		foreach ($sr as $key => $value) {
			$search[$i] = "%$key%";
			$replace[$i] = $value;
			$i++;
		}
		$content = file_get_contents( DIR_TPL.'forms_item/'.$file.'.tpl' );
		return str_replace($search, $replace, $content );
	}
	
	private function select( $name, $label, $option, $selected ) {
		$sr['name'] = $name;
		$sr['label'] = $label;
		$optionS = '';
		if( is_array( $option ) )
		foreach( $option as $key => $value ) {
			$selectedS = ( $selected == $key ) ? 'selected' : '';
			
			$optionS .= '<option '.$selectedS.' value="'.$key.'">'.$value.'</option>';
		}
		$sr['option'] = $optionS;
		return $this->getReplaceContent( $sr, 'select' );
	}
	
	private function hidden( $name, $value ) {
		$sr['name'] = $name;
		$sr['value'] = $value;
		return $this->getReplaceContent( $sr, 'hidden' );
	}
	
	private function file( $name, $label ) {
		$sr['name'] = $name;
		$sr['label'] = $label;
		return $this->getReplaceContent( $sr, 'file' );
	}
	
	private function captcha( $name, $label = "Введите код с картинки:") {
		$sr['name'] = $name;
		$sr['label'] = $label;
		$sr['address'] = ADDRESS;
		return $this->getReplaceContent( $sr, 'captcha' );
	}
	
	private function password ($name, $label = "", $default_v = "" ) {
		$sr['name'] = $name;
		$sr['label'] = $label;
		$sr['default_v'] = $default_v;
		return $this->getReplaceContent( $sr, 'password' );
	}
	
	private function text( $name, $label = "", $value = "", $default_v = "") {
		$sr['name'] = $name;
		$sr['label'] = $label;
		$sr['value'] = $value;
		$sr['default_v'] = $default_v;
		return $this->getReplaceContent( $sr, 'text' );
	}	
	private function textarea( $name, $label = "", $value = "", $default_v = "", $wysibb  = false ) {
		$sr['name'] = $name;
		$sr['label'] = $label;
		$sr['value'] = $value;
		$sr['default_v'] = $default_v;
		$sr['wysibb'] = $wysibb;
		return $this->getReplaceContent( $sr, 'textarea' );
	}
	
	private function submit( $name, $value, $class ) {
		$sr['name'] = $name;
		$sr['value'] = $value;
		$sr['class'] = $class;
		return $this->getReplaceContent( $sr, 'submit' );
	}
	
	public function goForm( $array ) {

		$form =	'<form class="'.$this->classForm.'" method="'.$this->method.'" action="'.$this->action.'">';
		
		if( !empty( $this->head ) )
			$form .=	'<h1>'.$this->head.'</h1>';
		
		foreach( $array as $key => $value) {
			switch( $key ) {
				case "submit" : {
					$form .= $this->submit( $value['name'], $value['value'], $value['class'] );
					break;
				}
				case "password" : {
					$form .= $this->password( $value['name'], $value['label'], $value['default']);
					break;
				}
				case "text" : {
					$form .= $this->text( $value['name'], $value['label'], $value['value'], $value['default'] );
					break;
				}
				case "textarea" : {
					$form .= $this->textarea( $value['name'], $value['label'], $value['value'], $value['default'], $value['wysibb']  );
					break;
				}
				case "captcha" : {
					$form .= $this->captcha( $value['name'], $value['label'] );
					break;
				}
				case "file" : {
					$form .= $this->file( $value['name'], $value['label'] );
					break;
				}
				case "hidden" : {
					$form .= $this->hidden( $value['name'], $value['value'] );
					break;
				} 
				case "select" : {
					$form .= $this->select( $value['name'], $value['label'],  $value['option'], $value['selected'] );
					break;
				} 
			}
		}
		$form .=	'</form>';
		return $form;
	}
	
}

?>