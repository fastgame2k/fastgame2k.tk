<?php
class grey {
	protected $title;
	protected $desc;
	protected $getCss;
	protected $getJs;
	protected $meta_key;
	protected $bottom;
	protected $sql;
	protected $userData;
	
	public function __construct() {
		session_start();
		$this->sql = new DataBase();
	}
	
	public function getContent() {
		if( !isset( $_SESSION['id'] ) && isset( $_COOKIE['userid'] ) ) {
			$check = $this->sql->select(
				'users',
				[ 'id' ],
				[ 'userid' => $_COOKIE['userid'] ]
			);
			if( is_array( $check ) ) {
				$_SESSION['id'] = $check[0]['id'];
			} 
		}	
		
		if( isset( $_SESSION['id'] ) ) {
			$this->userData = users::getId( $_SESSION['id'] );
		}
		
		$path = parse_url( $_SERVER['REQUEST_URI'] );
		$request = explode( '/', $path['path'] );
		$content = DEFAULT_APP;
		
		if( is_array( $request ) ) {
			if( !empty( $request[1] ) && !empty( $request[2] ) ) {
				$content = '';
				for( $i = 1; $i < count( $request ); $i++ ) {
					if( $i != count( $request ) - 1 )
						$content .= $request[$i].'/';
					else {
						$content .= $request[$i];
					}
				}
			} else if( !empty( $request[1] ) ){
				$content = $request[1];
			}
		}
		
		$content .= '/index';
		if ( !file_exists( DIR_TPL.$content.'.tpl' ) ) 
			$content = 'error/index';
		
		$eks = array();
		$sr['middle'] = $this->tpl( $eks, $content );

		return $this->tpl( $sr, "main", true );
	}	

	
	protected function tpl( $sr, $template, $rerurn = false ) {
		$template = DIR_TPL . $template . ".tpl";
		
		extract( $sr );
		ob_start(); 				 
		include( $template );
		if( !$rerurn ) {
			return ob_get_clean();
		} else {
			echo ob_get_clean();
		}
	}
	
	protected function pags( $count, $count_on_page, $link ) {
		if( $count < $count_on_page )
			return '';
		$count_on_page = ceil( $count / $count_on_page );
		
		$limit = 3;   ///лимит вывода строк
		$thiss = isset( $_GET['page'] ) ? $_GET['page'] + 1 : 1;
		$its_page = isset( $_GET['page'] ) ? $_GET['page'] : "";
		$start = $thiss - $limit;
		$end = $thiss + $limit;	
		$sr['active'] = "";
		$pages = "";
		if ( $its_page >= 1 ) { 
			$els["number_pages"][] = array(
				'number' => "Первая",
				'link' => $link,
				'active' => ""
			);
		}
		$sim = ( strpos( $link, "?" ) !== false ) ? "&amp;page=" : "?page=";
		
		for( $i=1; $i <= $count_on_page; $i++ ) {
			if ( $i >= $start && $i <= $end ) {
				if ( $i == $its_page ) { 
					$els["number_pages"][] = array(
						'active' => "active",
						'number' => $i,
						'link' => $link . $sim . $i
					);
				}
				else {
					$els["number_pages"][] = array(
						'active' => "",
						'number' => $i,
						'link' => $link . $sim . $i
					);
				}
			}
		}
		$sr['active'] = "";
		if ( $i > $its_page && ( $its_page + 2) < $i ) {
			$els["number_pages"][] = array(
				'active' => "",
				'number' => "След",
				'link' => $link.$sim.( $its_page + 2 )
			);
			$els["number_pages"][] = array(
				'active' => "",
				'number' => "Послед",
				'link' => $link.$sim.( $i - 1 )
			);			
		} 
		return $this->tpl( $els, "pagination" );
	}	
	
	static public  function msg() {
		$msg = "";
		if( isset( $_SESSION['err_msg'] ) ) {
			//$msg = '<div class="alert alert-danger" role="alert">'.$_SESSION['err_msg'].'</div>';
			$msg = '
<script>
$(window).load(function(){
     $(\'#msg_go\').attr( \'data-message\', \''.$_SESSION['err_msg'].'\');
    $("#msg_go").attr( "data-type", "error");
    $("#msg_go").trigger("click");
});
</script>
			';
			unset( $_SESSION['err_msg'] );
		}		
		
		if( isset( $_SESSION['msg'] ) ) {
			//$msg = '<div class="alert alert-success" role="alert">'.$_SESSION['msg'].'</div>';
			$msg = '<script>
$(window).load(function(){
     $(\'#msg_go\').attr( \'data-message\', \''.$_SESSION['msg'].'\');
    $("#msg_go").attr( "data-type", "success");
    $("#msg_go").trigger("click");
});
</script>';

			unset( $_SESSION['msg'] );
		}
		
		return $msg;
	}
	
	  
	public static function pre( $text ) {
		echo '<pre>';
		print_r( $text );
		die();
	}
	
	public static function notFound() {
		//header("HTTP/1.1 404 Not Found");
		// header("Status: 404 Not Found");
		return true;
	}
	

	static public function head ( $url = ADDRESS, $msg = "", $notFound = false ) {
		if( is_array( $msg ) )
		{
			foreach( $msg as $key => $value ) {
				$_SESSION[$key] = $value;
			}
		}
		if( $notFound === true ) {
			grey::notFound();
		}
		header("Location: ".$url);
		die();
	}
	
	
	static public function url( $view = "", $getUrl = "" ) {		
		if( !$view )
			return ADDRESS;
		
		$view = ( $view == DEFAULT_APP ) ? '' : $view.'/';
		
		if( !is_array( $getUrl ) ) {
			return ADDRESS.$view;
		}
		
		$z = 0;
		$addUrl = "";
		foreach( $getUrl as $key => $value ) {
			$sim = ( $z == 0 ) ? '?' : '&amp;';
			$addUrl .= $sim.$key.'='. $value;
			$z++;
		}
		return ADDRESS.$view.$addUrl;
	}
}

	
?>