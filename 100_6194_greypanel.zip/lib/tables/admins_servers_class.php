<?php
class admins_servers {  
	
	public static function addAmxBans ( $values, $host, $user, $pass, $bd, $prefix ){
		$DataBase = new DataBase( $host, $user, $pass, $bd, $prefix );
		return $DataBase->insert ( __CLASS__, $values );
	}
	
	public static function getAmxAdmin ( $where, $host, $user, $pass, $bd, $prefix ) {
		
		$DataBase = new DataBase( $host, $user, $pass, $bd, $prefix );

		$getAdmin = $DataBase->select( __CLASS__, '*', $where, 'admin_id' ); 
		return $getAdmin[0];
	}
	
	public static function updateAmxAdmin( $values, $where, $host, $user, $pass, $bd, $prefix  ) {
		$DataBase = new DataBase( $host, $user, $pass, $bd, $prefix );
		return $DataBase->update ( __CLASS__, $values, $where);
	}
	
	public static function delete( $where, $host, $user, $pass, $bd, $prefix  ) {
		$DataBase = new DataBase( $host, $user, $pass, $bd, $prefix );
		return $DataBase->delete ( __CLASS__, $where );
	}
}