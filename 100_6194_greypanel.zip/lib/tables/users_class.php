<?php
class users { 
	public static function select( $fields = '*', $where = "", $order = "", $up = true, $limit = "" ) {
		$DataBase = new DataBase();
		$search = $DataBase->select( 'users', $fields, $where, $order, $up, $limit );
		if( !is_array( $search ) ) 
			return null;
		foreach( $search as $value ) {
			$amx_id = isset( $value['amx_id'] ) ? $value['amx_id'] : '0';
			$vk_id = isset( $value['vk_id'] ) ? $value['vk_id'] : '0';
			$money = isset( $value['money'] ) ? $value['money'] : '0';
			$email = isset( $value['email'] ) ? $value['email'] : '';
			$password = isset( $value['password'] ) ? $value['password'] : '';
			$avatar = isset( $value['avatar'] ) ? $value['avatar'] : '';
			$group = isset( $value['group'] ) ? $value['group'] : '0';
			$count_like = isset( $value['count_like'] ) ? $value['count_like'] : '0';
			$count_theard = isset( $value['count_theard'] ) ? $value['count_theard'] : '0';
			$count_post = isset( $value['count_post'] ) ? $value['count_post'] : '0';
			$sql[] = [
				'id' => $value['id'],
				'url' => grey::url( 'user', [ 'id' => $value['id'] ] ),
				'amx_id' => $amx_id,
				'vk_id' => $vk_id,
				'money' => $money,
				'reg_data' => times::timeAgo( $value['reg_data'] ),
				'username' => htmlspecialchars( $value['username'] ),
				'email' => htmlspecialchars( $email ),
				'password' => htmlspecialchars( $password ),
				'group' => $group,
				'avatar' => htmlspecialchars( $avatar ),
				'count_like' => ( int ) $count_like,
				'count_theard' => ( int ) $count_theard,
				'count_post' => ( int ) $count_post,
			];
		}
		return $sql;
	}
	
	public static function getId( $id ) {
		$DataBase = new DataBase();
		foreach( $DataBase->select( 'users', '*', [ 'id' => $id ] ) as $value ) {
			$sql[] = [
				'id' => $value['id'],
				'url' => grey::url( 'user', [ 'id' => $value['id'] ] ),
				'amx_id' => $value['amx_id'],
				'vk_id' => $value['vk_id'],
				'money' => $value['money'],
				'reg_data' => times::timeAgo( $value['reg_data'] ),
				'username' => htmlspecialchars( $value['username'] ),
				'email' => htmlspecialchars( $value['email']),
				'password' => htmlspecialchars( $value['password']),
				'group' => $value['group'],
				'avatar' => htmlspecialchars( $value['avatar'] ),
				'count_like' => ( int ) $value['count_like'],
				'count_theard' => ( int ) $value['count_theard'],
				'count_post' => ( int ) $value['count_post'],
			];
		}
		return $sql[0];
	}	
	public static function getIdMini( $id ) {
		$DataBase = new DataBase();
		foreach( $DataBase->select( 'users', ['id','username','group','avatar','reg_data', 'count_like', 'count_theard', 'count_post' ], [ 'id' => $id ] ) as $value ) {
			$sql[] = [
				'id' => $value['id'],
				'url' => grey::url( 'user', [ 'id' => $value['id'] ] ),
				'username' => htmlspecialchars( $value['username'] ),
				'group' => ( int ) $value['group'],
				'count_like' => ( int ) $value['count_like'],
				'count_theard' => ( int ) $value['count_theard'],
				'count_post' => ( int ) $value['count_post'],
				'avatar' => htmlspecialchars( $value['avatar'] ),
				'reg_data' => times::timeAgo( $value['reg_data'] ),
			];
		}
		return $sql[0];
	}
	
	public static function search( $words ) {
		$DataBase = new DataBase();
		$sql = $DataBase->search( 'users', $words, [ 'username', 'email' ] );
		return $sql;
	}
	
	public static function insert( $values ) {
		$DataBase = new DataBase();
		return $DataBase->insert ( 'users', $values);
	}
	
	public static function update( $values, $where ) {
		$DataBase = new DataBase();
		return $DataBase->update ( 'users', $values, $where);
	}
	
	public static function delete( $where ) {
		$DataBase = new DataBase();
		return $DataBase->delete ( 'users', $where );
	}
	
	public static function total( $where = '', $order = 'id' ) {
		$DataBase = new DataBase();
		$total = $DataBase->select( __CLASS__, ['COUNT(*)'], $where, $order );
		return $total[0]['COUNT(*)'];
	}
}

?>