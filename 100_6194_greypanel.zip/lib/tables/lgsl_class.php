<?php
class lgsl { 
	public static function select( $fields = '*', $where = "", $order = "", $up = true, $limit = "" ) {
		$DataBase = new DataBase();
		$search = $DataBase->select( __CLASS__, $fields, $where, $order, $up, $limit );
		if( !is_array( $search ) ) 
			return null;
		foreach( $search as $value ) {
			$sql[] = [
				'id' => $value['id'],
				'type' => $value['type'],
				'ip' =>  $value['ip'],
				'c_port' =>  $value['c_port'],
				'q_port' =>  $value['q_port'],
				's_port' =>  $value['s_port'],
				'disabled' =>  $value['disabled'],
				'status' =>  $value['status'],
				'cache' => unserialize ( $value['cache'] ),
				'cache_time' =>  $value['cache_time'],
			];
		}
		return $sql;
	}
	
	public static function insert( $values ) {
		$DataBase = new DataBase();
		return $DataBase->insert ( __CLASS__, $values);
	}
	
	public static function update( $values, $where ) {
		$DataBase = new DataBase();
		return $DataBase->update ( __CLASS__, $values, $where);
	}
	
	public static function delete( $where ) {
		$DataBase = new DataBase();
		return $DataBase->delete ( __CLASS__, $where );
	}
	
	function lgsl_type_list()
	{
		return [
			"halflife"      => "Counter - Strike 1.6",
			"source"   => "Counter - Strike : CSGO",
		];
	}
}

?>