<?php

class menu {  
	
	public static function select( $fields = '*', $where = "", $order = "", $up = true, $limit = ""  ) {
		$DataBase = new DataBase();
		$search = $DataBase->select( __CLASS__, $fields, $where, $order, $up, $limit);
		if( !is_array( $search ) )
			return null;
		foreach( $search as $value ) {
			$sql[] = [
				'id' => 		( int ) $value['id'] , 
				'num' => 	( int ) $value['num'], 
				'active' =>		( int ) $value['active'], 
				'ses' =>		( int ) $value['ses'], 
				'text' => 		htmlspecialchars( $value['text'] ), 
				'desc' => 		htmlspecialchars( $value['desc'] ), 
				'module' => 		htmlspecialchars( $value['module'] ), 
				'icon' => 		htmlspecialchars( $value['icon'] ), 
			];
		}
		return $sql;
	}	
	
	public static function insert( $values ) {
		$DataBase = new DataBase();
		return $DataBase->insert ( __CLASS__, $values);
	}
	
	public static function update( $values, $where ) {
		$DataBase = new DataBase();
		return $DataBase->update ( __CLASS__, $values, $where);
	}
	
	public static function delete( $where ) {
		$DataBase = new DataBase();
		return $DataBase->delete ( __CLASS__, $where );
	}
}