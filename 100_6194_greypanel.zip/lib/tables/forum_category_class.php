<?php
class forum_category { 
	public static function select( $fields = '*', $where = "", $order = "", $up = true, $limit = "" ) {
		$DataBase = new DataBase();
		$search = $DataBase->select( 'forum_category', $fields, $where, $order, $up, $limit );
		
		if( !is_array( $search ) )
			return null;
		
		foreach( $DataBase->select( 'forum_category', $fields, $where, $order, $up, $limit ) as $value ) {
			$num = isset( $value['num'] ) ? $value['num'] : '0';
			$sql[] = [
				'id' => $value['id'],
				'url' => grey::url( 'index', [ 'cat' => $value['id'] ] ),
				'title' => htmlspecialchars( $value['title'] ),
				'desc' => htmlspecialchars( $value['desc'] ),
				'num' => $num,
				'forums_info' => forum_forums::select( '*', [ 'category' => $value['id'] ] ),
				
			];
		}
		return $sql;
	}
	
	public static function getId( $id ) {
		$DataBase = new DataBase();
		foreach( $DataBase->select( 'forum_category', '*', [ 'id' => $id ] ) as $value ) {
			$sql[] = [
				'id' => $value['id'],
				'url' => grey::url( 'index', [ 'cat' => $value['id'] ] ),
				'title' => htmlspecialchars( $value['title'] ),
				'desc' => htmlspecialchars( $value['desc'] ),
				
			];
		}
		return $sql[0];
	}
	
	public static function insert( $values ) {
		$DataBase = new DataBase();
		return $DataBase->insert ( 'forum_category', $values);
	}
	
	public static function update( $values, $where ) {
		$DataBase = new DataBase();
		return $DataBase->update ( 'forum_category', $values, $where);
	}
	
	public static function delete( $where ) {
		$DataBase = new DataBase();
		return $DataBase->delete ( 'forum_category', $where );
	}
}