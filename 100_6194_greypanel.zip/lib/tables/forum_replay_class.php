<?php
class forum_replay {  
	
	public static function getId( $id, $limit ) {
		$DataBase = new DataBase();
		$search = $DataBase->select( __CLASS__, '*', [ 'theard_id' => $id ], 'created',  true, $limit );
		if( !is_array( $search ) )
			return null;
		
		foreach( $search as $value ) {
			$sql[] = [
				'id' => $value['id'], 
				'theard_id' => $value['theard_id'], 
				'autor_id' => $value['autor_id'], 
				'content' => htmlspecialchars( $value['content'] ),  
				'created' => times::timeAgo( $value['created'] ), 
				'content_bb' => func::bcod( htmlspecialchars( $value['content'] ) ),
				'this_liked' => unserialize ( $value['this_liked'] ), 
				'user_info' => users::getId( ( int ) $value['autor_id'] ),
				
			];
		}
		return $sql;
	}
	
	public static function last( $id ) {
		
		$DataBase = new DataBase();
		$get_replay = $DataBase->select( __CLASS__, [ 'created', 'autor_id' ], [ 'theard_id' => $id ], 'created',  false, 1  );
		if( !is_array( $get_replay) ) 
			return null;
		
		return users::getId( ( int ) $get_replay[0]['autor_id'] );
		
	}
	
	public static function total( $where ) {
		$DataBase = new DataBase();
		$total = $DataBase->select( __CLASS__, ['COUNT(*)'], $where );
		return $total[0]['COUNT(*)'];
	}
}