<?php
class vip_servers {  
	
	public static function select( $id = '' ) {
		
		if( is_array( $id ) ) {
			$where = $id;
		}
		else if( !empty( $id ) ){
			$where = [ 'id' => $id ];
		} else {
			$where = '';
		}
		
		
		$DataBase = new DataBase();
		$search = $DataBase->select( __CLASS__, [ 'id', 'server_name', 'server_port', 'server_ip', 'privileg_data' ], $where );
		
		if( !is_array( $search ) )
			return null;
		
		foreach( $search as $value ) {
			$sql[] = [
				'id' => htmlspecialchars( $value['id'] ), 
				'server_name' => htmlspecialchars( $value['server_name'] ), 
				'server_port' => htmlspecialchars( $value['server_port'] ), 
				'server_ip' => htmlspecialchars( $value['server_ip'] ), 
				'privileg_data' => unserialize( $value['privileg_data'] ), 
			];
		}
		return $sql;
	}	
	public static function selectAdmin() {
		$DataBase = new DataBase();
		$search = $DataBase->select( __CLASS__, '*' );
		if( !is_array( $search ) )
			return null;
		
		foreach( $search as $value ) {
			$sql[] = [
				'id' => $value['id'], 
				'host' => htmlspecialchars( $value['host'] ), 
				'user' => htmlspecialchars( $value['user'] ), 
				'password' => htmlspecialchars( $value['password'] ), 
				'bd' => htmlspecialchars( $value['bd'] ), 
				'prefix' => htmlspecialchars( $value['prefix'] ), 
				'server_name' => htmlspecialchars( $value['server_name'] ), 
				'server_port' => htmlspecialchars( $value['server_port'] ), 
				'server_ip' => htmlspecialchars( $value['server_ip'] ), 
				'amx_id' => ( int ) $value['amx_id'], 
				'type' => ( int ) $value['type'], 
				'privileg_data' => unserialize( $value['privileg_data'] ), 
			];
		}
		return $sql;
	}
	public static function getIdAdmin( $id ) {
		
		$DataBase = new DataBase();
		
		$getServer = $DataBase->select( __CLASS__, '*', [ 'id' => $id ] ); 
 
		if( !is_array( $getServer ) )
			return null;
		
		$sql = [
			'id' => ( int ) $getServer[0]['id'], 
			'host' => htmlspecialchars( $getServer[0]['host'] ), 
			'user' => htmlspecialchars( $getServer[0]['user'] ), 
			'password' => htmlspecialchars( $getServer[0]['password'] ), 
			'bd' => htmlspecialchars( $getServer[0]['bd'] ), 
			'type' => htmlspecialchars( $getServer[0]['type'] ), 
			'prefix' => htmlspecialchars( $getServer[0]['prefix'] ), 
			'server_name' => htmlspecialchars( $getServer[0]['server_name'] ), 
			'server_port' => htmlspecialchars( $getServer[0]['server_port'] ), 
			'server_ip' =>  htmlspecialchars($getServer[0]['server_ip'] ), 
			'amx_id' =>  htmlspecialchars($getServer[0]['amx_id'] ), 
			'privileg_data' => unserialize( $getServer[0]['privileg_data'] ), 
		];
		return $sql;
	}
	
	public static function insert( $values ) {
		$DataBase = new DataBase();
		return $DataBase->insert ( __CLASS__, $values);
	}
	
	public static function update( $values, $where ) {
		$DataBase = new DataBase();
		return $DataBase->update ( __CLASS__, $values, $where);
	}
	
	public static function delete( $where ) {
		$DataBase = new DataBase();
		return $DataBase->delete ( __CLASS__, $where );
	}
	/*
	public static function addAmxBans ( $values, $table, $host, $user, $pass, $bd, $prefix ){
		$DataBase = new DataBase( $host, $user, $pass, $bd, $prefix );
		return $DataBase->insert ( $table, $values );
	}
	
	public static function getAmxAdmin ( $steamId, $host, $user, $pass, $bd, $prefix ) {
		$DataBase = new DataBase( $host, $user, $pass, $bd, $prefix );
		$getServer = $DataBase->select( 'amxadmins', '*', [ 'steamid' => $steamId ] ); 
		return $getServer[0];
	}
	
	public static function updateAmxAdmin( $values, $where, $host, $user, $pass, $bd, $prefix  ) {
		$DataBase = new DataBase( $host, $user, $pass, $bd, $prefix );
		return $DataBase->update ( 'amxadmins', $values, $where);
	}
	*/
}