<?php
class money_logs {  
	
	public static function select( $fields = '*', $where = "", $order = "", $up = true, $limit = ""  ) {
		$DataBase = new DataBase();
		$search = $DataBase->select( __CLASS__, $fields, $where, $order, $up, $limit);
		if( !is_array( $search ) )
			return null;
		foreach( $search as $value ) {
			$sql[] = [
				'id' => 		( int ) $value['id'] , 
				'user_id' => 	( int ) $value['user_id'], 
				'tupe' => 		( int ) $value['tupe'] , 
				'money' =>		( int ) $value['money'], 
				'title' => 		htmlspecialchars( $value['title'] ), 
			];
		}
		return $sql;
	}	
	
	public static function insert( $values ) {
		$DataBase = new DataBase();
		return $DataBase->insert ( __CLASS__, $values);
	}
	
	public static function update( $values, $where ) {
		$DataBase = new DataBase();
		return $DataBase->update ( __CLASS__, $values, $where);
	}
	
	public static function delete( $where ) {
		$DataBase = new DataBase();
		return $DataBase->delete ( __CLASS__, $where );
	}
}