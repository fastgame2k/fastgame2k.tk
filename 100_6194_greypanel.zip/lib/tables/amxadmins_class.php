<?php
class amxadmins {  
	
	public static function addAmxBans ( $values, $host, $user, $pass, $bd, $prefix ){
		$DataBase = new DataBase( $host, $user, $pass, $bd, $prefix );
		return $DataBase->insert ( __CLASS__, $values );
	}
	
	public static function getAmxAdmin ( $steamId, $host, $user, $pass, $bd, $prefix ) {
		$DataBase = new DataBase( $host, $user, $pass, $bd, $prefix );
		$getServer = $DataBase->select( __CLASS__, '*', [ 'steamid' => $steamId ] ); 
		return $getServer[0];
	}
	
	public static function updateAmxAdmin( $values, $where, $host, $user, $pass, $bd, $prefix  ) {
		$DataBase = new DataBase( $host, $user, $pass, $bd, $prefix );
		return $DataBase->update ( __CLASS__, $values, $where);
	}
}