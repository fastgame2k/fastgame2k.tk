<?php
class forum_theards { 
	public static function select( $fields = '*', $where = "", $order = "", $up = true, $limit = "", $debud = false ) {
		$DataBase = new DataBase();
		
		$search = $DataBase->select( 'forum_theards', $fields, $where, $order, $up, $limit, $debud );
		if( !is_array( $search ) )
			return null;
		foreach( $search as $value ) {
			$category = isset( $value['category'] ) ? $value['category'] : '';
			$sql[] = [
				'id' => $value['id'],
				'url' => grey::url( 'forum/topic', [ 'id' => $value['id'] ] ),
				'title' => htmlspecialchars( $value['title'] ),
				'content' => htmlspecialchars( $value['content'] ),
				'content_bb' => func::bcod( htmlspecialchars( $value['content'] ) ),
				'created' => times::timeAgo( $value['created'] ),
				'autor_id' => ( int ) $value['autor_id'],
				'this_liked' => unserialize ( $value['this_liked'] ),
				'status' => ( int ) $value['status'],
				'closed' => ( int ) $value['closed'],
				'deleted' => ( int ) $value['deleted'],
				'category' => ( int ) $category,
				'count_replay' => ( int ) $value['count_replay'],
				'user_info' => users::getId( ( int ) $value['autor_id'] ),
				'forum_info' => forum_forums::getId( ( int ) $value['forum_id'] ),
				'last_post' => times::timeAgo( $value['last_post'] ),
				
			];
		}
		return $sql;
	}
	
	public static function getId( $id ) {
		$DataBase = new DataBase();
		foreach( $DataBase->select( 'forum_theards', '*', [ 'id' => $id ] ) as $value ) {
			$category = isset( $value['category'] ) ? $value['category'] : '';
			$sql[] = [
				'id' => $value['id'],
				'url' => grey::url( 'forum/topic', [ 'id' => $value['id'] ] ),
				'title' => htmlspecialchars( $value['title'] ),
				'content' => htmlspecialchars( $value['content'] ),
				'created' => times::timeAgo( $value['created'] ),
				'last_post' => times::timeAgo( $value['last_post'] ),
				'autor_id' => ( int ) $value['autor_id'],
				'this_liked' => unserialize ( $value['this_liked'] ),
				'status' => ( int ) $value['status'],
				'closed' => ( int ) $value['closed'],
				'deleted' => ( int ) $value['deleted'],
				'category' => ( int ) $category,
				'count_replay' => ( int ) $value['count_replay'],
				'user_info' => users::getId( ( int ) $value['autor_id'] ),
				'forum_info' => forum_forums::getId( ( int ) $value['forum_id'] ),
				'content_bb' => func::bcod( htmlspecialchars( $value['content'] ) ),
			];
		}
		return $sql[0];
	}
	
	public static function last( $id ) {
		$DataBase = new DataBase();
		$sql = $DataBase->select( 
			'forum_theards', 
			[ 'id', 'title', 'autor_id', 'last_post' ], 
			[ 'forum_id' => $id, 'deleted' => '0' ],
			'id',
			false,
			1
		);
		
		if( !is_array( $sql ) )
			return false;
		
		$getReplays = forum_replay::last( $sql[0]['id'] );
		if( $getReplays != null ) {
			$sql= [
				'url' => grey::url( 'forum/topic', [ 'id' => $sql[0]['id'] ] ),
				'title' => htmlspecialchars( $sql[0]['title'] ),
				'last_post' =>  times::timeAgo( $sql[0]['last_post'] ),
				'user_info' => $getReplays,
				
			]; 	
			return $sql;
		}
		$sql= [
			'url' => grey::url( 'forum/topic', [ 'id' => $sql[0]['id'] ] ),
			'title' => htmlspecialchars( $sql[0]['title'] ),
			'last_post' =>  times::timeAgo( $sql[0]['last_post'] ),
			'user_info' => users::getId( ( int ) $sql[0]['autor_id'] ),
			
		]; 	
		return $sql;
	}
	
	public static function total( $where ) {
		$DataBase = new DataBase();
		$total = $DataBase->select( 'forum_theards', ['COUNT(*)'], $where );
		return $total[0]['COUNT(*)'];
	}
	
	public static function insert( $values ) {
		$DataBase = new DataBase();
		return $DataBase->insert ( __CLASS__, $values);
	}
	
	public static function update( $values, $where ) {
		$DataBase = new DataBase();
		return $DataBase->update ( __CLASS__, $values, $where);
	}
	
	public static function delete( $where ) {
		$DataBase = new DataBase();
		return $DataBase->delete ( __CLASS__, $where );
	}
}