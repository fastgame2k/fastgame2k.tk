<?php
class csstats { 
	public static function select( $fields = '*', $where = "", $order = "id", $up = true, $limit = "" ) {
		$DataBase = new DataBase( CSSTATS_IP_ADRES, CSSTATS_DB_USER, CSSTATS_DB_PASSWORD, CSSTATS_DB, CSSTATS_PREFIX, CSSTATS_CODIROVKA );
		
		$search = $DataBase->select( CSSTATS_TABLE, $fields, $where, $order, $up, $limit );
		if( !is_array( $search ) )
			return null;
		
		foreach( $search as $value ) {
			if( $value['kills'] != "0" ) {
				$effect = floor( ( 100 * $value['kills'] ) / ( $value['kills'] + $value['deaths'] ) );
			}
			else 
				$effect = '0';
			$sql[] = [
				'id' => $value['id'],
				'name' => htmlspecialchars( $value['name'] ),
				'kills' => ( int ) $value['kills'],
				'deaths' => ( int ) $value['deaths'],
				'hs' => ( int ) $value['hs'],
				'tks' => ( int ) $value['tks'],
				'shots' => ( int ) $value['shots'],
				'hits' => ( int ) $value['hits'],
				'dmg' => ( int ) $value['dmg'],
				'bombdef' => ( int ) $value['bombdef'],
				'bombdefused' => ( int ) $value['bombdefused'],
				'bombplants' => ( int ) $value['bombplants'],
				'bombexplosions' => ( int ) $value['bombexplosions'],
				'hits_xml' => $value['hits_xml'],
				'first_join' => $value['first_join'],
				'last_join' => $value['last_join'],
				'effect' => $effect,
			];
		}
		return $sql;
	}	
	
	public static function total( $where = '', $order = 'id' ) {
		$DataBase = new DataBase( CSSTATS_IP_ADRES, CSSTATS_DB_USER, CSSTATS_DB_PASSWORD, CSSTATS_DB, CSSTATS_PREFIX, CSSTATS_CODIROVKA );
		$total = $DataBase->select( CSSTATS_TABLE, ['COUNT(*)'], $where, $order );
		return $total[0]['COUNT(*)'];
	}
	
	public static function search( $words, $order = 'id' ) {
		$DataBase = new DataBase( CSSTATS_IP_ADRES, CSSTATS_DB_USER, CSSTATS_DB_PASSWORD, CSSTATS_DB, CSSTATS_PREFIX, CSSTATS_CODIROVKA );
		$sql = $DataBase->search( CSSTATS_TABLE, $words, [ 'player_nick', 'player_ip', 'server_name', 'server_ip' ], $order );
		return $sql;
	}
}

?>