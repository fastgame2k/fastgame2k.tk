<?php
class chat { 
	public static function select( $limit, $where = '', $up = false ) {
		$fields = '*';
		$order = 'time_add';
		$DataBase = new DataBase();
		$search = $DataBase->select( __CLASS__, $fields, $where, $order, $up, $limit );
		if( !is_array( $search ) ) 
			return null;
		
		
		foreach( $search as $value ) {
			$sql[] = [
				'id' => $value['id'],
				'autor_id' => $value['autor_id'], 
				'msg' => htmlspecialchars( $value['msg'] ), 
				'time_add' => times::timeAgo( $value['time_add'] ), 
			];
		}
		return $sql;
	}
	
	public static function insert( $values ) {
		$DataBase = new DataBase();
		return $DataBase->insert ( __CLASS__, $values);
	}
	
	public static function update( $values, $where ) {
		$DataBase = new DataBase();
		return $DataBase->update ( __CLASS__, $values, $where);
	}
	
	public static function delete( $where ) {
		$DataBase = new DataBase();
		return $DataBase->delete ( __CLASS__, $where );
	}
}

?>