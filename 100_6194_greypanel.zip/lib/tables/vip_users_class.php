<?php
class vip_users {  
	
	public static function select( $where = '' ) {
		$DataBase = new DataBase();
		$search = $DataBase->select( __CLASS__, [ '*' ], $where );
		if( !is_array( $search ) )
			return null;
		foreach( $search as $value ) {
			$timeAgo = $value['expired'] - time();
			$sql[] = [
				'id' => htmlspecialchars( $value['id'] ), 
				'expired' => ( int ) $value['expired'], 
				'amx_id' => ( int ) $value['amx_id'], 
				'user_id' => ( int ) $value['user_id'], 
				'server_data' => vip_servers::select( [ 'id' => $value['server_id'] ] ), 
				'custom_flags' => htmlspecialchars( $value['custom_flags'] ), 
				'timeAgo' => times::get_sec( $timeAgo ), 
			];
		}
		return $sql;
	}	
	
	public static function insert( $values ) {
		$DataBase = new DataBase();
		return $DataBase->insert ( __CLASS__, $values);
	}
	
	public static function update( $values, $where ) {
		$DataBase = new DataBase();
		return $DataBase->update ( __CLASS__, $values, $where);
	}
	
	public static function delete( $where ) {
		$DataBase = new DataBase();
		return $DataBase->delete ( __CLASS__, $where );
	}
}