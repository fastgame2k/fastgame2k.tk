<?php
class bans { 
	public static function select( $fields = '*', $where = "", $order = "bid", $up = true, $limit = "" ) {
		$DataBase = new DataBase( AMXBANS_IP_ADRES, AMXBANS_DB_USER, AMXBANS_DB_PASSWORD, AMXBANS_DB, AMXBANS_PREFIX, AMXBANS_CODIROVKA );
		$search = $DataBase->select( __CLASS__, $fields, $where, $order, $up, $limit );
		if( !is_array( $search ) )
			return null;
		
		foreach( $DataBase->select( __CLASS__, $fields, $where, $order, $up, $limit ) as $value ) {
			
			$sql[] = [
				'bid' => $value['bid'],
				'player_nick' => htmlspecialchars( $value['player_nick'] ),
				'admin_nick' => htmlspecialchars( $value['admin_nick'] ),
				'ban_reason' => htmlspecialchars( $value['ban_reason'] ),
				'cs_ban_reason' => htmlspecialchars( $value['cs_ban_reason'] ),
				'ban_created' => ( int ) $value['ban_created'],
				'ban_created_formate' => times::timeAgo( $value['ban_created'] ),
				'expired' => ( int ) $value['expired'],
				'server_name' => htmlspecialchars( $value['server_name'] ),
			];
		}
		return $sql;
	}	
	
	public static function total( $where = '', $order = 'bid' ) {
		$DataBase = new DataBase( AMXBANS_IP_ADRES, AMXBANS_DB_USER, AMXBANS_DB_PASSWORD, AMXBANS_DB, AMXBANS_PREFIX );
		$total = $DataBase->select( __CLASS__, ['COUNT(*)'], $where, $order );
		return $total[0]['COUNT(*)'];
	}
	
	public static function search( $words, $order = 'bid' ) {
		$DataBase = new DataBase( AMXBANS_IP_ADRES, AMXBANS_DB_USER, AMXBANS_DB_PASSWORD, AMXBANS_DB, AMXBANS_PREFIX, AMXBANS_CODIROVKA );
		$sql = $DataBase->search( __CLASS__, $words, [ 'player_nick', 'player_ip', 'server_name', 'server_ip' ], $order );
		return $sql;
	}
	
	public static function delete( $where ) {
		$DataBase = new DataBase( AMXBANS_IP_ADRES, AMXBANS_DB_USER, AMXBANS_DB_PASSWORD, AMXBANS_DB, AMXBANS_PREFIX );
		return $DataBase->delete ( __CLASS__, $where );
	}
}

?>