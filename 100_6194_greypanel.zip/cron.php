<?php
mb_internal_encoding("utf-8");
require_once "conf/config.php";

if( isset( $_GET['cron'] ) && $_GET['cron'] == CRON_KEY ) {
	set_include_path( get_include_path() . PATH_SEPARATOR . "lib/mysql" . PATH_SEPARATOR . "lib/tables" . PATH_SEPARATOR . "lib/function" );
	spl_autoload_extensions("_class.php");
	spl_autoload_register();
	require_once "conf/ittems.php";
	
	
	$sql = new DataBase();

	//echo '<pre>';

	$time = time();
	$getAdminList = $sql->select( 
		'vip_users',
		'*',
		"`expired` <= '{$time}'"
	);
	for( $i = 0; $i < count( $getAdminList ); $i++ ) {
		#находим юзеров FTP
		if( $getAdminList[$i]['amx_id'] == '0' ) {
			
			
		} else {
			$vip_servers = vip_servers::getIdAdmin( 
				$getAdminList[$i]['server_id'] 
			);
			
			$host = $vip_servers['host'];
			$user = $vip_servers['user'];
			$password = $vip_servers['password'];
			$bd = $vip_servers['bd'];
			$prefix = $vip_servers['prefix'];
			
			#”дал¤ем права
			admins_servers::delete( 
				[ 
					'admin_id' => $getAdminList[$i]['amx_id'],
					'server_id' => $vip_servers['amx_id'],
				], 
			$host, $user, $password, $bd, $prefix);

						
		}
		#удаляем всех
		vip_users::delete( [ 
			'id' => $getAdminList[$i]['id']
		]);			

	}

	$selectServersFtp = vip_servers::selectAdmin();
	if( is_array( $selectServersFtp ) ) {
		for( $z = 0; $z < count( $selectServersFtp ); $z++ ){
			if( $selectServersFtp[$z]['type'] == '1' ) {
				$ftp_server = $selectServersFtp[$z]['host'];
				$user = $selectServersFtp[$z]['user'];
				$password = $selectServersFtp[$z]['password'];
				$bd = $selectServersFtp[$z]['bd']; 
				$prefix = $selectServersFtp[$z]['prefix'];
				
				$conn_id = ftp_connect( $ftp_server );
				if ( ftp_login( $conn_id, $user, $password ) ) {
					
					#Получаем всех юзеров с сервера
					$getAllUsersServer = vip_users::select([
						'server_id' => $selectServersFtp[$z]['id']
					]);
					
					if( is_array( $getAllUsersServer ) ){
						
						$formateUsers = '';
						
						for( $i = 0; $i < count( $getAllUsersServer ); $i++ ) {
							#Получаем юзера
							$getUserMoney = $sql->select(
								'users',
								[ 'username','password', 'money'  ],
								[ 'id' => $getAllUsersServer[$i]['user_id'] ]
							);	
							$formateUsers .= "\"".$getUserMoney[0]['username']."\" \"".$getUserMoney[0]['password']."\" \"".$getAllUsersServer[$i]['custom_flags']."\" \"a\" ;Автоматическое добавление, конец админки ".$getAllUsersServer[$i]['timeAgo']."\n";
						}
						
						$of = fopen( 'upload/users.ini', "w+"); 
						$line=fgets( $of ); 
						rewind( $of ); 
						fwrite( $of, $formateUsers );
						fclose($of);
						
						$fp = fopen( 'upload/users.ini', 'r' );
						#Загружаем новый файл на сервер
						ftp_fput( $conn_id, $bd, $fp, FTP_ASCII );
						ftp_close( $conn_id );
						fclose($fp);
					}
				}
			}
			 
		}
		//print_R($selectServersFtp);
	}
	die('1');
}
exit( '0' );
?>